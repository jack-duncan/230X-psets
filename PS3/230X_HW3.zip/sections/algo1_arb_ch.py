"""
RIT ALGO1 - Algorithmic Arbitrage 1 - LOW LATENCY BUILD
========================================================
Tuned for a competitive run: multiple students are running the same arb, so
the winner is whoever's order reaches the book first.

WHAT MAKES THIS FAST (vs. the straightforward version)
-------------------------------------------------------
1. NO CASE CALL IN THE HOT PATH
   The simple version calls /v1/case every iteration - a third round trip per
   loop just to ask "is the case still running?". Here that check happens on a
   timer (every CASE_CHECK_EVERY seconds), so the trading loop is 2 calls, not 3.

2. CONCURRENT BOOK FETCHES
   Both order books are fetched in parallel instead of one-after-the-other.
   Halves the fetch time AND makes the two snapshots simultaneous - fetching
   sequentially means you compare a fresh M book against a ~20ms stale A book,
   which can show a crossing that has already gone.

3. POSITIONS TRACKED LOCALLY
   The simple version calls /v1/securities after spotting a crossing but before
   sending orders - a full round trip at the worst possible moment. Here the
   position is held in memory, updated from fills, and only re-synced from the
   API on a slow timer.

4. BOTH LEGS FIRED SIMULTANEOUSLY
   Sequential legs mean the second order lands ~20ms after the first, by which
   time a competitor may have taken that side. Both legs go out in parallel.

5. CONNECTION POOLING / KEEP-ALIVE
   One Session per worker thread, with a connection pool, so no TCP handshake
   per request. A fresh connection each call would add multiples of the RTT.

6. QUIET HOT PATH
   print() is slow, especially in a notebook - 20 prints/sec will visibly lag
   the loop. Status printing is throttled; only actual trades print immediately.

CASE CONSTRAINTS (ALGO1 brief)
-------------------------------
  max 10,000 shares/order | max 25,000 gross or net position | 300 tick window
"""

import threading
import time
from concurrent.futures import ThreadPoolExecutor

import requests

# --------------------------------------------------------------------------
# CONFIG
# --------------------------------------------------------------------------
BASE_URL = 'http://136.152.32.17:10002'
AUTH = ('YOUR_USERNAME', 'YOUR_PASSWORD')

TICKER_M = 'CRZY_M'
TICKER_A = 'CRZY_A'

MAX_ORDER = 20000        # hard per-order cap from the brief

# The brief says "25,000 shares gross or net" - i.e. BOTH must hold, combined
# across the two venues. Tracking each venue's limit separately (the earlier
# bug) lets gross exposure reach 50,000 (e.g. M=+25,000, A=-25,000, net=0,
# gross=50,000) while looking perfectly fine on a per-venue check. Both caps
# are enforced explicitly below.
GROSS_LIMIT = 25000      # |pos_M| + |pos_A| must never exceed this
NET_LIMIT = 25000        # pos_M + pos_A must never exceed this in magnitude

MIN_EDGE = 0.00000001          # min $/share crossing worth taking (1 tick)

# Float subtraction of prices is inexact: 9.22 - 9.21 evaluates to
# 0.009999999999999787, which is NOT >= 0.01. Without this tolerance the
# algorithm silently skips every one-cent crossing - i.e. most of them.
EDGE_EPS = 1e-9

LOOP_SLEEP = 0.0002        # 0 = poll as fast as the network allows
CASE_CHECK_EVERY = 5.0   # seconds between /v1/case checks
POSITION_SYNC_EVERY = 0  # seconds between authoritative position re-syncs
STATUS_PRINT_EVERY = 3.0   # seconds between "still watching" status lines

# Stop opening NEW arbs this many ticks before the case ends, and spend the
# remaining time closing out. An arb opened at tick 299 whose second leg
# doesn't fill leaves you holding real exposure into settlement with no time
# left to fix it - the worst possible way to lose money on a "riskless" trade.
CLOSE_OUT_TICKS = 10

REQUEST_TIMEOUT = 1.0    # fail fast; a hung call must not stall the loop

# --------------------------------------------------------------------------
# SESSION HANDLING - one pooled Session per thread
# --------------------------------------------------------------------------
_local = threading.local()


def sess():
    s = getattr(_local, 'session', None)
    if s is None:
        s = requests.Session()
        s.auth = AUTH
        adapter = requests.adapters.HTTPAdapter(
            pool_connections=4, pool_maxsize=8, max_retries=0
        )
        s.mount('http://', adapter)
        _local.session = s
    return s


# --------------------------------------------------------------------------
# STATE
# --------------------------------------------------------------------------
positions = {TICKER_M: 0, TICKER_A: 0}
_pos_lock = threading.Lock()

stats = {'checks': 0, 'arbs': 0, 'shares': 0, 'rejects': 0, 'throttled': 0,
         'imbalances': 0, 'unflattened': 0}


def adjust_position(ticker, delta):
    with _pos_lock:
        positions[ticker] += delta


# --------------------------------------------------------------------------
# API CALLS
# --------------------------------------------------------------------------
def fetch_top_of_book(ticker):
    """Return (bid_price, bid_qty, ask_price, ask_qty) or None on failure."""
    try:
        r = sess().get(
            f'{BASE_URL}/v1/securities/book',
            params={'ticker': ticker},
            timeout=REQUEST_TIMEOUT,
        )
        if r.status_code == 429:
            stats['throttled'] += 1
            return None
        book = r.json()
        bid, ask = book['bids'][0], book['asks'][0]
        return (
            bid['price'], bid['quantity'] - bid.get('quantity_filled', 0),
            ask['price'], ask['quantity'] - ask.get('quantity_filled', 0),
        )
    except Exception:
        return None


def send_market_order(ticker, action, quantity):
    """Fire a market order. Returns shares actually filled."""
    quantity = int(quantity)
    if quantity <= 0:
        return 0
    try:
        r = sess().post(
            f'{BASE_URL}/v1/orders',
            params={'ticker': ticker, 'type': 'MARKET',
                    'quantity': quantity, 'action': action},
            timeout=REQUEST_TIMEOUT,
        )
        if not r.ok:
            if r.status_code == 429:
                stats['throttled'] += 1
            stats['rejects'] += 1
            print(f'   REJECT {action} {quantity} {ticker}: {r.status_code} {r.text[:120]}')
            return 0
        filled = r.json().get('quantity_filled', 0) or 0
        signed = filled if action == 'BUY' else -filled
        adjust_position(ticker, signed)
        return filled
    except Exception as exc:
        stats['rejects'] += 1
        print(f'   ERROR {action} {quantity} {ticker}: {exc}')
        return 0


def sync_positions():
    """Authoritative position refresh from the server."""
    try:
        r = sess().get(f'{BASE_URL}/v1/securities', timeout=REQUEST_TIMEOUT)
        if not r.ok:
            return
        with _pos_lock:
            for s in r.json():
                if s['ticker'] in positions:
                    positions[s['ticker']] = s.get('position', 0)
    except Exception:
        pass


# --------------------------------------------------------------------------
# SIZING
# --------------------------------------------------------------------------
def gross_position():
    """|pos_M| + |pos_A| - total shares held, regardless of direction."""
    with _pos_lock:
        return abs(positions[TICKER_M]) + abs(positions[TICKER_A])


def room_for_size(buy_ticker, sell_ticker, size):
    """
    Largest amount of size that keeps BOTH gross and net within their caps
    after the trade. Buying buy_ticker moves its position toward +size;
    selling sell_ticker moves its position toward -size.

    This is checked as a binary search over trade size rather than solved
    algebraically, because gross uses abs() - not linear - so a closed-form
    solution has to case-split on the sign of each current position anyway.
    A binary search is shorter, correct, and easy to verify by testing.
    """
    with _pos_lock:
        pos_buy = positions[buy_ticker]
        pos_sell = positions[sell_ticker]

    def within_limits(s):
        new_buy = pos_buy + s
        new_sell = pos_sell - s
        gross = abs(new_buy) + abs(new_sell)
        net = new_buy + new_sell
        return gross <= GROSS_LIMIT and abs(net) <= NET_LIMIT

    if not within_limits(0):
        return 0   # already over a limit - do not add to it
    if within_limits(size):
        return size

    lo, hi = 0, size
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if within_limits(mid):
            lo = mid
        else:
            hi = mid
    return lo


def size_trade(buy_ticker, sell_ticker, ask_qty, bid_qty):
    """
    Largest size that is simultaneously:
      - available at the touch on BOTH legs (never walk the book on an arb)
      - within the per-order cap
      - within BOTH the gross and net position limits, combined across venues
    """
    depth_capped = int(min(ask_qty, bid_qty, MAX_ORDER))
    if depth_capped <= 0:
        return 0
    return max(0, room_for_size(buy_ticker, sell_ticker, depth_capped))


def find_arb(bk_m, bk_a):
    """
    Pure decision logic - no I/O, so it can be unit tested offline.

    bk_m / bk_a are (bid_price, bid_qty, ask_price, ask_qty) tuples.
    Returns a dict describing the trade, or None if there's nothing to do.
    """
    bid_m, bidq_m, ask_m, askq_m = bk_m
    bid_a, bidq_a, ask_a, askq_a = bk_a

    edge_buy_m = bid_a - ask_m   # buy Main, sell Alternate
    edge_buy_a = bid_m - ask_a   # buy Alternate, sell Main

    # Both directions can be profitable at once only if the market is crossed
    # against itself in a strange way, but if it happens, take the larger
    # edge - not whichever direction happens to be checked first. An if/elif
    # on edge_buy_m would silently leave a bigger opportunity on the table
    # whenever both are positive.
    candidates = []
    if edge_buy_m >= MIN_EDGE - EDGE_EPS:
        candidates.append((edge_buy_m, TICKER_M, TICKER_A, askq_m, bidq_a, ask_m, bid_a))
    if edge_buy_a >= MIN_EDGE - EDGE_EPS:
        candidates.append((edge_buy_a, TICKER_A, TICKER_M, askq_a, bidq_m, ask_a, bid_m))

    if not candidates:
        return None

    edge, buy_t, sell_t, askq, bidq, buy_px, sell_px = max(candidates, key=lambda c: c[0])
    size = size_trade(buy_t, sell_t, askq, bidq)
    return {'buy': buy_t, 'sell': sell_t, 'size': size,
            'edge': edge, 'buy_px': buy_px, 'sell_px': sell_px}


# --------------------------------------------------------------------------
# EXECUTION
# --------------------------------------------------------------------------
def net_position():
    """Net CRZY exposure across both venues (the directional risk)."""
    with _pos_lock:
        return positions[TICKER_M] + positions[TICKER_A]


def flatten(max_attempts=3, verbose=True, order_pool=None):
    """
    Drive BOTH venue positions to zero - not just their sum.

    net_position() == 0 is satisfied by M=+20000, A=-20000, which still
    means 40,000 real shares are held (gross exposure), fully exposed to
    each venue's own price risk even though they cancel in aggregate. This
    function closes each ticker's position individually, so "flat" means
    zero shares outstanding on both exchanges, matching the case brief's
    description of an arb ending in "a zero-position in CRZY" per venue.

    A single offsetting order is NOT enough: the order can itself partially
    fill or be rejected, leaving you exposed. So this re-syncs from the
    server, re-measures, and retries - and tells you honestly if it could
    not finish the job.

    Returns True if BOTH venues are at zero, False if exposure remains.
    """
    for attempt in range(1, max_attempts + 1):
        sync_positions()
        with _pos_lock:
            pos_m, pos_a = positions[TICKER_M], positions[TICKER_A]

        if pos_m == 0 and pos_a == 0:
            return True

        if verbose:
            print(f'   FLATTEN attempt {attempt}: M={pos_m:+}  A={pos_a:+}  '
                  f'gross={abs(pos_m)+abs(pos_a)}')

        # Close each venue's own position independently - a long position
        # is closed by selling THAT venue, not by buying on the other one.
        # Both legs go out at once (via order_pool, when available) rather
        # than one after the other - same reasoning as fire_both_legs: the
        # second leg should not sit waiting behind the first.
        jobs = []
        if pos_m > 0:
            jobs.append((TICKER_M, 'SELL', min(pos_m, MAX_ORDER)))
        elif pos_m < 0:
            jobs.append((TICKER_M, 'BUY', min(-pos_m, MAX_ORDER)))
        if pos_a > 0:
            jobs.append((TICKER_A, 'SELL', min(pos_a, MAX_ORDER)))
        elif pos_a < 0:
            jobs.append((TICKER_A, 'BUY', min(-pos_a, MAX_ORDER)))

        if order_pool is not None and len(jobs) > 1:
            futures = [order_pool.submit(send_market_order, *j) for j in jobs]
            for f in futures:
                f.result()
        else:
            for j in jobs:
                send_market_order(*j)

    sync_positions()
    with _pos_lock:
        pos_m, pos_a = positions[TICKER_M], positions[TICKER_A]
    if pos_m != 0 or pos_a != 0:
        stats['unflattened'] = abs(pos_m) + abs(pos_a)
        print(f'   !! STILL EXPOSED after {max_attempts} attempts: '
              f'M={pos_m:+}  A={pos_a:+}')
        return False
    return True


def fire_both_legs(order_pool, buy_ticker, sell_ticker, size):
    """
    Send both legs at once and report the fills.

    Takes order_pool specifically (not the shared pool used for book
    fetches) so a burst of order activity - the initial pair, a repair
    order, a multi-attempt flatten - never competes with, or gets queued
    behind, the next price check. Book fetches and order execution are on
    separate worker pools end to end.
    """
    f_buy = order_pool.submit(send_market_order, buy_ticker, 'BUY', size)
    f_sell = order_pool.submit(send_market_order, sell_ticker, 'SELL', size)
    bought, sold = f_buy.result(), f_sell.result()

    stats['arbs'] += 1
    stats['shares'] += min(bought, sold)

    if bought != sold:
        # Asymmetric fill leaves real directional exposure.
        imbalance = bought - sold
        stats['imbalances'] += 1
        print(f'   imbalance {imbalance:+} (bought {bought}, sold {sold})')

        # First try the cheap fix: one offsetting order for the difference.
        if imbalance > 0:
            send_market_order(sell_ticker, 'SELL', min(imbalance, MAX_ORDER))
        else:
            send_market_order(buy_ticker, 'BUY', min(-imbalance, MAX_ORDER))

        # Then verify against the server and retry if it didn't take.
        # gross_position() != 0 is the correct "not flat" check here: it is
        # zero only when BOTH venues are individually at zero, which is what
        # flatten() actually targets (net==0 alone would miss M=+X, A=-X).
        if gross_position() != 0:
            flatten(order_pool=order_pool)

    return bought, sold


# --------------------------------------------------------------------------
# MAIN LOOP
# --------------------------------------------------------------------------
def main():
    # Separate pools for book fetches vs. order execution. Book fetches
    # happen on every loop iteration (the hot path); orders happen rarely
    # but can burst (both legs, a repair order, several flatten attempts).
    # Sharing one pool means an order burst can occupy every worker and
    # delay the very next price check - exactly when you need it least,
    # since you're likely mid-trade and want fresh prices immediately after.
    book_pool = ThreadPoolExecutor(max_workers=2)
    order_pool = ThreadPoolExecutor(max_workers=4)

    sync_positions()

    # Wait for the case to go live.
    while True:
        try:
            case = sess().get(f'{BASE_URL}/v1/case', timeout=REQUEST_TIMEOUT).json()
            if case['status'] == 'ACTIVE':
                break
            print(f"waiting... case status = {case['status']}")
        except Exception as exc:
            print(f'waiting... {exc}')
        time.sleep(1.0)

    print(f"CASE ACTIVE - tick {case['tick']}/{case['ticks_per_period']} - trading\n")

    last_tick = case['tick']
    total_ticks = case['ticks_per_period']
    last_tick_at = time.time()

    t_start = time.time()
    next_case_check = t_start + CASE_CHECK_EVERY
    next_pos_sync = t_start + POSITION_SYNC_EVERY
    next_status = t_start + STATUS_PRINT_EVERY

    while True:
        now = time.time()

        # --- periodic (not per-iteration) case status check ---------------
        if now >= next_case_check:
            try:
                case = sess().get(f'{BASE_URL}/v1/case', timeout=REQUEST_TIMEOUT).json()
                if case['status'] != 'ACTIVE':
                    print(f"\nCase {case['status']} - stopping.")
                    break
                last_tick, last_tick_at = case['tick'], now
                total_ticks = case['ticks_per_period']
            except Exception:
                pass
            next_case_check = now + CASE_CHECK_EVERY

        # Ticks run at ~1/sec, so estimate the current tick between checks.
        est_tick = last_tick + (now - last_tick_at)
        closing_out = est_tick >= (total_ticks - CLOSE_OUT_TICKS)

        if closing_out:
            if gross_position() != 0:
                print(f'\n[tick ~{est_tick:.0f}] CLOSE-OUT: flattening before '
                      f'the case ends')
                flatten(max_attempts=5, order_pool=order_pool)
            else:
                # Flat and near the end - nothing left to do but wait it out.
                time.sleep(0.25)
            continue

        # --- periodic authoritative position re-sync ----------------------
        if now >= next_pos_sync:
            sync_positions()
            next_pos_sync = now + POSITION_SYNC_EVERY

        # --- HOT PATH: both books in parallel, on the dedicated book pool --
        f_m = book_pool.submit(fetch_top_of_book, TICKER_M)
        f_a = book_pool.submit(fetch_top_of_book, TICKER_A)
        bk_m, bk_a = f_m.result(), f_a.result()

        stats['checks'] += 1

        if bk_m is None or bk_a is None:
            continue

        bid_m, _, ask_m, _ = bk_m
        bid_a, _, ask_a, _ = bk_a

        arb = find_arb(bk_m, bk_a)

        if arb is not None and arb['size'] > 0:
            print(f"ARB  buy {arb['buy']}@{arb['buy_px']}  "
                  f"sell {arb['sell']}@{arb['sell_px']}  "
                  f"edge={arb['edge']:.3f}  size={arb['size']}")
            fire_both_legs(order_pool, arb['buy'], arb['sell'], arb['size'])

        elif arb is not None:
            # Crossed, but no room under the position limit.
            if now >= next_status:
                print(f"   crossed (edge={arb['edge']:.3f}) but position limit "
                      f"reached - skipping")
                next_status = now + STATUS_PRINT_EVERY

        # --- throttled status line (printing is slow, keep it out of the way)
        elif now >= next_status:
            rate = stats['checks'] / max(now - t_start, 0.001)
            print(f"   M {bid_m}/{ask_m}  A {bid_a}/{ask_a}  "
                  f"| {rate:.0f} checks/s  arbs={stats['arbs']}  "
                  f"shares={stats['shares']}")
            next_status = now + STATUS_PRINT_EVERY

        if LOOP_SLEEP:
            time.sleep(LOOP_SLEEP)

    # ---- wrap up ---------------------------------------------------------
    elapsed = time.time() - t_start
    sync_positions()

    # Last chance: if the case ended while we still held exposure, try to
    # close it. This may fail if the case is already closed for trading -
    # which is exactly why CLOSE_OUT_TICKS exists.
    if gross_position() != 0:
        print(f'\nEnded with M={positions[TICKER_M]:+} A={positions[TICKER_A]:+} '
              f'- attempting close-out')
        flatten(max_attempts=3, order_pool=order_pool)

    print(f"\n{'='*58}")
    print(f"ran {elapsed:.1f}s | {stats['checks']} checks "
          f"({stats['checks']/max(elapsed,0.001):.0f}/s)")
    print(f"arbs taken: {stats['arbs']}  shares arbed: {stats['shares']}")
    print(f"imbalanced fills: {stats['imbalances']}  "
          f"rejects: {stats['rejects']}  throttled(429): {stats['throttled']}")
    print(f"final position: {TICKER_M}={positions[TICKER_M]}  "
          f"{TICKER_A}={positions[TICKER_A]}  net={net_position():+}  "
          f"gross={gross_position()}")
    if gross_position() != 0:
        print('WARNING: finished with open directional exposure')
    print('='*58)

    book_pool.shutdown(wait=False)
    order_pool.shutdown(wait=False)


if __name__ == '__main__':
    main()

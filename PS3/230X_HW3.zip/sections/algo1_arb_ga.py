#!/usr/bin/env python3
"""
ALGO1 - Algorithmic Arbitrage 1 : cross-exchange arbitrage bot for the
Rotman Interactive Trader (RIT).

CRZY trades on two exchanges as CRZY_M (Main) and CRZY_A (Alternate), each with
its own independent limit order book.  Occasionally the books become *crossed*
(the bid on one exchange is above the ask on the other).  This bot polls
GET /securities as fast as the client allows, detects the cross, and fires both
legs (buy cheap / sell rich) as MARKET orders *immediately* - before it knows
anything about book depth.  Depth arrives on two more connections in parallel
and drives follow-up rounds.  In a room full of polling arb bots the winner is
whoever gets the POST out first, so nothing is allowed to sit in front of it.

Quick start
-----------
    export RIT_API_KEY=<the key from the API icon in the RIT client status bar>

    # 1. Watch only - detects crosses, submits nothing.  ALWAYS run this first.
    python3 algo1_arb.py --dry-run --verbose

    # 2. Live.
    python3 algo1_arb.py

    # 3. Live, conservative:  only take crosses worth >= 1 cent/share after a
    #    0.5 cent/share assumed trading cost on each leg.
    python3 algo1_arb.py --min-profit 0.01 --cost 0.005

    # 4. Live, with the opt-in passive quoting overlay (see README).
    python3 algo1_arb.py --quote

Ctrl-C exits cleanly, cancels any resting quotes, and prints the session tally.

Requires: nothing but the Python 3 standard library.

API reference (RIT Client REST API 1.0.3, https://rit.306w.ca/RIT-REST-API/1.0.3/):
  GET  /case              -> {name, period, tick, ticks_per_period, total_periods,
                              status in (ACTIVE|PAUSED|STOPPED), is_enforce_trading_limits}
  GET  /securities        -> [{ticker, position, bid, bid_size, ask, ask_size, ...}]
  GET  /securities/book   -> {"bid": [Order...], "ask": [Order...]}  (Order carries
                              price, quantity, quantity_filled)
  GET  /orders?status=    -> [Order...]      (defaults to OPEN)
  POST /orders            -> Order {order_id, ticker, type, quantity, action, price,
                              quantity_filled, vwap, status in (OPEN|TRANSACTED|CANCELLED)}
                              query params: ticker, type, quantity, action, price, dry_run
                              success carries an `X-Wait-Until` header: seconds to
                              wait before the next insertion on the SAME ticker.
  DELETE /orders/{id}     -> {success: true}
  POST /commands/cancel   -> {cancelled_order_ids: [...]}   params: all|ticker|ids|query
  GET  /limits            -> [{name, gross, net, gross_limit, net_limit, ...}]
  Auth: X-API-Key header.  Rate limit -> HTTP 429 with `Retry-After` header and a
  `wait` body field, both in seconds.
"""

from __future__ import annotations

import argparse
import http.client
import json
import logging
import os
import signal
import sys
import threading
import time
from collections import deque
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple
from urllib.parse import urlencode, urlparse

# --------------------------------------------------------------------------- #
# Configuration constants
# --------------------------------------------------------------------------- #

BASE_URL_DEFAULT = "http://localhost:9999/v1"

TICKER_M = "CRZY_M"
TICKER_A = "CRZY_A"
TICKERS: Tuple[str, str] = (TICKER_M, TICKER_A)

MAX_ORDER_SIZE = 10_000          # shares per order (case rule)
POSITION_LIMIT = 25_000          # shares, applies to BOTH gross and net (case rule)
DEFAULT_SAFETY_MARGIN = 500      # shares of headroom kept under the limit

MIN_PROFIT_PER_SHARE = 0.0       # required edge per share, after costs
TRADING_COST_PER_SHARE = 0.0     # per-share cost on EACH leg (ALGO1 has none)

POLL_INTERVAL_SECONDS = 0.0      # 0 = poll as fast as the client answers
# Adaptive pacing (AIMD) for the query-class endpoints.  See ``Pacer``.
PACE_STEP = 0.005                # additive increase on an isolated 429
PACE_FACTOR = 1.5                # multiplicative increase on a burst of 429s
PACE_BURST = 0.5                 # 429s this close together count as a burst
PACE_MAX = 0.25                  # never pace slower than this
PACE_CLEAN = 2.0                 # seconds of quiet before we try speeding up
PACE_DECAY_PERIOD = 1.0          # at most one shrink per this long
PACE_DECAY_RATE = 0.8            # geometric shrink toward the floor
PACE_FLOOR_MARGIN = 1.1          # a failing interval + 10% becomes the floor
PACE_FLOOR_RELAX = 0.98          # the floor itself relaxes slowly when quiet
PACE_SAFETY = 1.15               # aim this much slower than the rate that failed
PACE_COOLDOWN = 0.05             # concurrent 429s count as one congestion event
PACE_MIN_RATE = 2.0              # below this the rate estimate is not trusted

# Proactive request budget (--rate-limit).  The RIT client allows roughly 10
# requests/second in the trial runs and 100 in the final, counted across ALL
# endpoints, so the only safe approach is to spend that budget deliberately
# rather than discover it by being refused.
RATE_RESERVE_DEFAULT = 2.0       # tokens/second polls may never touch
BUDGET_OVERHEAD = 1.1            # /case once a second, /trader once a regime
DEPTH_MIN_RATE = 30.0            # below this, two book requests are not worth it
BOOK_BUDGET_WAIT = 0.005         # depth is skipped if it cannot go out this soon
CASE_POLL_SECONDS = 1.0          # how often to re-check /case
TALLY_INTERVAL_SECONDS = 30.0
NET_TOLERANCE = 0                # shares of net exposure tolerated before flattening
BLIND_SIZE = 1000                # shares struck without a book read (--no-depth)
LIMIT_WAIT_SECONDS = 0.2         # how long limit legs rest before cancelling
IMBALANCE_MIN = 100              # shares of leg imbalance worth reversing
RESERVE_SMALL_BUDGET = 6.0       # 2 books + 2 orders + cancel + reversal
SMALL_BUDGET = 20.0              # ... at or below this many requests/second
RESTRIKE_COOLDOWN = 0.5          # seconds before the same cross may be struck again
POST_STRIKE_SLEEP = 0.1          # let the client's view catch up with our fills
FLATTEN_CONFIRM_SECONDS = 0.3    # a net must persist this long before we act on it

HTTP_TIMEOUT = 2.0               # seconds; the client is local, so keep it tight
MAX_RETRIES = 3
BACKOFF_MAX_SECONDS = 1.0

DIR_BUY_M = "BUY_M_SELL_A"       # buy CRZY_M, sell CRZY_A
DIR_BUY_A = "BUY_A_SELL_M"       # buy CRZY_A, sell CRZY_M

DEFAULT_TICK = 0.01
QUOTE_SIZE_DEFAULT = 2_000
QUOTE_TOLERANCE_TICKS = 1
REQUOTE_INTERVAL_SECONDS = 0.25
MAX_DIVERGENCE_TICKS = 3
OPEN_ORDER_POLL_SECONDS = 0.5

# Regime monitor
MODE_AGGRESSIVE = "AGGRESSIVE"
MODE_CONSERVATIVE = "CONSERVATIVE"
MODE_UNWIND = "UNWIND"
REGIME_INTERVAL_SECONDS = 10.0
REGIME_MIN_TRADES = 5
# UNWIND is OFF by default: benchmarked against --no-regime on one-sided flow
# it did not pay (median P&L $293 vs $316), so the default threshold is set
# above anything gross utilisation can reach.  Lower it to 0.8 to enable the
# one-sided passive quotes.  See BENCH.md.
UNWIND_THRESHOLD = 1.1           # gross utilisation that starts unwinding
UNWIND_EXIT = 0.5                # ... and the one that stops it (hysteresis)
CONSERVATIVE_CLEAN_WINDOWS = 2   # clean windows needed to go back to aggressive
FLATTEN_AT_TICKS = 3             # flatten net exposure this many ticks from the end

LOG = logging.getLogger("algo1")


# --------------------------------------------------------------------------- #
# Data types
# --------------------------------------------------------------------------- #


@dataclass
class Quote:
    """Top of book plus position for one ticker, from GET /securities."""

    ticker: str
    bid: Optional[float]
    ask: Optional[float]
    bid_size: int
    ask_size: int
    position: int

    @property
    def tradeable(self) -> bool:
        return self.bid is not None and self.ask is not None


@dataclass
class Level:
    """One aggregated price level of a book side."""

    price: float
    size: int


@dataclass
class Opportunity:
    """A detected cross, before sizing."""

    direction: str          # DIR_BUY_M or DIR_BUY_A
    buy_ticker: str
    sell_ticker: str
    ask_cheap: float        # price we buy at
    bid_rich: float         # price we sell at
    edge: float             # per-share profit after costs
    top_size: int           # min(ask_size, bid_size) at top of book
    scarce: str = "sell"    # which leg is the small crossing order: "sell" or "buy"


@dataclass
class Tally:
    """Session counters.  The only mutable state carried across iterations."""

    crosses_seen: int = 0
    crosses_traded: int = 0
    shares_traded: int = 0
    est_profit: float = 0.0
    leg_risk_events: int = 0
    flattens: int = 0
    rate_limit_hits: int = 0
    order_429: int = 0              # 429s on an ORDER: the ones that cost money
    stale_restrikes: int = 0        # re-strikes suppressed as stale quotes
    errors: int = 0
    quotes_posted: int = 0
    quotes_cancelled: int = 0
    passive_fills: int = 0
    passive_shares: int = 0
    poll_ms: float = 0.0            # interval the pacer has converged to
    mode: str = MODE_AGGRESSIVE
    started: float = field(default_factory=time.time)

    def summary(self) -> str:
        return (
            "TALLY | elapsed=%5.1fs crosses_seen=%d traded=%d shares=%d "
            "est_profit=$%.2f leg_risk=%d flattens=%d http429=%d(orders=%d) "
            "errors=%d "
            "poll=%.0fms mode=%s stale=%d quotes=%d/%d passive=%d(%d sh)"
            % (
                time.time() - self.started,
                self.crosses_seen,
                self.crosses_traded,
                self.shares_traded,
                self.est_profit,
                self.leg_risk_events,
                self.flattens,
                self.rate_limit_hits,
                self.order_429,
                self.errors,
                self.poll_ms,
                self.mode,
                self.stale_restrikes,
                self.quotes_posted,
                self.quotes_cancelled,
                self.passive_fills,
                self.passive_shares,
            )
        )


@dataclass
class Signals:
    """One regime interval's worth of execution evidence.

    Everything here is a *direct* execution signal.  P&L is deliberately not a
    trigger anywhere: it lags the decision by minutes and is dominated by how
    many crosses happened to appear, not by how well we traded them.
    """

    trades: int = 0             # filled legs in the window
    slippage: float = 0.0       # quantity-weighted mean, per share, signed
    fill_ratio: float = 1.0     # quantity_filled / quantity
    capture_ratio: float = 0.0  # shares filled / shares the touch showed
    gross_util: float = 0.0
    leg_risk: int = 0
    rate_limited: int = 0
    pos_m: int = 0
    pos_a: int = 0
    total_slippage: float = 0.0
    total_trades: int = 0
    nlv: Optional[float] = None


@dataclass
class Config:
    api_key: str
    base_url: str = BASE_URL_DEFAULT
    min_profit: float = MIN_PROFIT_PER_SHARE
    cost: float = TRADING_COST_PER_SHARE
    poll: float = POLL_INTERVAL_SECONDS
    rate_limit: float = 0.0         # requests/second allowed by the client
    rate_reserve: float = RATE_RESERVE_DEFAULT
    restrike_cooldown: float = RESTRIKE_COOLDOWN
    post_strike_sleep: float = POST_STRIKE_SLEEP
    position_mode: str = "auto"
    legs: str = "scarce"             # limit | market
    limit_wait: float = LIMIT_WAIT_SECONDS
    imbalance_min: int = IMBALANCE_MIN
    blind_size: int = BLIND_SIZE
    margin: int = DEFAULT_SAFETY_MARGIN
    max_order: int = MAX_ORDER_SIZE
    position_limit: int = POSITION_LIMIT
    dry_run: bool = False
    depth: bool = True
    max_rounds: int = 5             # paired orders per detected cross
    # -- passive quoting overlay (opt in) --
    quote: bool = False
    quote_size: int = QUOTE_SIZE_DEFAULT
    quote_tolerance: int = QUOTE_TOLERANCE_TICKS
    requote_interval: float = REQUOTE_INTERVAL_SECONDS
    max_divergence: int = MAX_DIVERGENCE_TICKS
    tick: Optional[float] = None    # None -> infer from the quoted prices
    # -- regime monitor (on by default) --
    regime: bool = True
    regime_interval: float = REGIME_INTERVAL_SECONDS
    slip_threshold: Optional[float] = None   # None -> minus one tick
    regime_min_trades: int = REGIME_MIN_TRADES
    unwind_threshold: float = UNWIND_THRESHOLD
    unwind_exit: float = UNWIND_EXIT
    flatten_at: float = FLATTEN_AT_TICKS


# --------------------------------------------------------------------------- #
# Pure logic (unit-tested; no network)
# --------------------------------------------------------------------------- #


def profitable_quantity(
    book_bids: Sequence[Level],
    book_asks: Sequence[Level],
    cost: float = 0.0,
    min_profit: float = 0.0,
    cap: Optional[int] = None,
) -> Tuple[int, float]:
    """Walk two books like a matching engine and return (quantity, gross_profit).

    ``book_bids`` are the bids of the *expensive* exchange (we sell into them),
    highest price first.  ``book_asks`` are the asks of the *cheap* exchange (we
    lift them), lowest price first.  We keep consuming while

        bid_price - ask_price - 2 * cost > min_profit

    Costs are charged per share on *each* leg, hence ``2 * cost``.  Returns the
    cumulative shares that clear that hurdle and the total profit on them.

    ``cap`` stops the walk early, which gives the true profit of the best
    ``cap`` shares rather than a flat top-of-book approximation.
    """
    i = j = 0
    qty = 0
    profit = 0.0
    bid_left = book_bids[0].size if book_bids else 0
    ask_left = book_asks[0].size if book_asks else 0

    while i < len(book_bids) and j < len(book_asks):
        bid = book_bids[i]
        ask = book_asks[j]
        edge = bid.price - ask.price - 2.0 * cost
        if edge <= min_profit:
            break
        take = min(bid_left, ask_left)
        if cap is not None:
            remaining_cap = int(cap) - qty
            if remaining_cap <= 0:
                break
            take = min(take, remaining_cap)
        if take <= 0:
            # Skip an empty level on whichever side is exhausted.
            if bid_left <= 0:
                i += 1
                bid_left = book_bids[i].size if i < len(book_bids) else 0
            if ask_left <= 0:
                j += 1
                ask_left = book_asks[j].size if j < len(book_asks) else 0
            continue
        qty += take
        profit += take * edge
        bid_left -= take
        ask_left -= take
        if bid_left == 0:
            i += 1
            bid_left = book_bids[i].size if i < len(book_bids) else 0
        if ask_left == 0:
            j += 1
            ask_left = book_asks[j].size if j < len(book_asks) else 0

    return qty, profit


def remaining_after_strike(
    book_bids: Sequence[Level],
    book_asks: Sequence[Level],
    fired: int,
    cost: float = 0.0,
    min_profit: float = 0.0,
) -> Tuple[int, float]:
    """Shares still worth taking after a first strike of ``fired`` shares.

    The first strike went out as a MARKET order before the books were known, so
    it consumed the *top* of each side.  ``profitable_quantity`` also walks from
    the top, so the leftover is simply the total profitable quantity minus what
    we already fired, priced as the difference of the two cumulative profits.
    """
    fired = max(0, int(fired))
    total_q, total_p = profitable_quantity(book_bids, book_asks, cost, min_profit)
    if fired >= total_q:
        return 0, 0.0
    if fired == 0:
        return total_q, total_p
    _q, fired_p = profitable_quantity(
        book_bids, book_asks, cost, min_profit, cap=fired
    )
    return total_q - fired, total_p - fired_p


def _gross(pos_m: int, pos_a: int) -> int:
    return abs(pos_m) + abs(pos_a)


def _net(pos_m: int, pos_a: int) -> int:
    return pos_m + pos_a


def capped_size(
    direction: str,
    q: int,
    pos_m: int,
    pos_a: int,
    limit: int = POSITION_LIMIT,
    margin: int = DEFAULT_SAFETY_MARGIN,
    max_order: int = MAX_ORDER_SIZE,
) -> int:
    """Largest tradeable size <= ``q`` that keeps gross and net inside the limits.

    ``direction`` is DIR_BUY_M (pos_m += s, pos_a -= s) or DIR_BUY_A
    (pos_m -= s, pos_a += s).

    Both gross = |pos_m| + |pos_a| and net = pos_m + pos_a are convex piecewise
    linear in the trade size, so the feasible set is an interval containing 0 and
    a binary search for the largest feasible size is exact.  A trade that runs
    *against* an existing position reduces gross, so it is permitted well beyond
    the naive ``limit - current_gross`` headroom -- that falls out of the search
    for free.  If we already sit outside a limit, the effective cap becomes the
    current level, i.e. we may still trade but never make the breach worse.
    """
    if q <= 0 or direction not in (DIR_BUY_M, DIR_BUY_A):
        return 0

    sign = 1 if direction == DIR_BUY_M else -1
    hi = min(int(q), int(max_order))
    if hi <= 0:
        return 0

    effective = max(0, int(limit) - int(margin))
    gross_cap = max(effective, _gross(pos_m, pos_a))
    net_cap = max(effective, abs(_net(pos_m, pos_a)))

    def feasible(size: int) -> bool:
        m = pos_m + sign * size
        a = pos_a - sign * size
        return _gross(m, a) <= gross_cap and abs(_net(m, a)) <= net_cap

    if feasible(hi):
        return hi
    lo = 0
    # Invariant: feasible(lo) is True, feasible(hi) is False.
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if feasible(mid):
            lo = mid
        else:
            hi = mid
    return lo


def detect_cross_raw(
    bid_m: Optional[float],
    ask_m: Optional[float],
    bid_size_m: int,
    ask_size_m: int,
    bid_a: Optional[float],
    ask_a: Optional[float],
    bid_size_a: int,
    ask_size_a: int,
    cost: float = 0.0,
    min_profit: float = 0.0,
) -> Optional[Opportunity]:
    """Cross detection straight off the numbers, allocating nothing when flat.

    This is the hot path: on the overwhelmingly common no-cross iteration it
    performs two subtractions and two comparisons and returns None without
    building a single object.
    """
    if bid_m is None or ask_m is None or bid_a is None or ask_a is None:
        return None

    hurdle = min_profit + 2.0 * cost
    edge_bm = bid_a - ask_m - 2.0 * cost      # buy M, sell A
    edge_ba = bid_m - ask_a - 2.0 * cost      # buy A, sell M
    if bid_a - ask_m <= hurdle and bid_m - ask_a <= hurdle:
        return None

    best: Optional[Opportunity] = None
    best_key = None
    if edge_bm > min_profit:
        size = min(ask_size_m, bid_size_a)
        best = Opportunity(DIR_BUY_M, TICKER_M, TICKER_A, ask_m, bid_a, edge_bm, size)
        best_key = (edge_bm * max(size, 0), edge_bm)
    if edge_ba > min_profit:
        size = min(ask_size_a, bid_size_m)
        key = (edge_ba * max(size, 0), edge_ba)
        if best is None or key > best_key:  # type: ignore[operator]
            best = Opportunity(DIR_BUY_A, TICKER_A, TICKER_M, ask_a, bid_m,
                               edge_ba, size)
    return best


def detect_cross(
    q_m: Quote,
    q_a: Quote,
    cost: float = 0.0,
    min_profit: float = 0.0,
) -> Optional[Opportunity]:
    """Quote-object wrapper around :func:`detect_cross_raw`."""
    return detect_cross_raw(
        q_m.bid, q_m.ask, q_m.bid_size, q_m.ask_size,
        q_a.bid, q_a.ask, q_a.bid_size, q_a.ask_size,
        cost, min_profit,
    )


def pace_on_rate_limit(
    interval: float,
    floor: float,
    base: float,
    since_last: float,
    observed_rate: float = 0.0,
    step: float = PACE_STEP,
    factor: float = PACE_FACTOR,
    burst: float = PACE_BURST,
    cap: float = PACE_MAX,
    margin: float = PACE_FLOOR_MARGIN,
    safety: float = PACE_SAFETY,
) -> Tuple[float, float]:
    """New (interval, floor) after a 429 on a query-class endpoint.

    ``observed_rate`` is how many query requests per second we were *actually*
    making when the server refused one.  That is the single most useful number
    available: the limit is at or below it, so one period of it plus a safety
    margin is a good first guess at a workable interval, and it converges in one
    step instead of creeping up 5 ms at a time while every 429 costs a full
    ``Retry-After`` sleep.

    Without it (no measurement yet) this falls back to additive increase for an
    isolated 429 and multiplicative for a burst -- TCP's shape, for TCP's
    reason: we know only that the interval we just used was too fast.

    The interval that failed, plus a margin, becomes a *floor* that the decay
    is not allowed to undercut; that is what makes this converge instead of
    sawtoothing back into the limit every second.
    """
    if interval <= 0.0:
        proposed = max(base, step)
    elif 0.0 <= since_last <= burst:
        proposed = interval * factor
    else:
        proposed = interval + step
    if observed_rate >= PACE_MIN_RATE:
        # Below a couple of requests a second the estimate is noise (a cold
        # start, a stalled loop) and 1/rate would be a wild over-correction.
        proposed = max(proposed, safety / observed_rate)
    new_floor = max(floor, interval * margin + 0.002)
    return (min(max(proposed, base), cap),
            min(max(new_floor, base), cap))


def pace_decay(
    interval: float,
    floor: float,
    base: float,
    rate: float = PACE_DECAY_RATE,
    relax: float = PACE_FLOOR_RELAX,
) -> Tuple[float, float]:
    """New (interval, floor) after one quiet second: shrink back toward ``base``.

    The interval shrinks geometrically but never below the floor, and the floor
    itself relaxes slowly, so a burst of rate limiting that has passed does not
    slow the bot down for the rest of the case.
    """
    new_floor = max(base, floor * relax)
    new_interval = max(new_floor, interval * rate)
    if new_interval <= base + 0.0005:
        # Within half a millisecond of the configured poll: snap to it, so the
        # geometric decay actually terminates instead of asymptoting.
        return base, base
    return new_interval, new_floor


class Pacer:
    """Poll interval that adapts to whatever the client's query rate limit is.

    ``--poll`` is the floor, not the answer.  With no rate limiting the bot sits
    at ``--poll`` (0 = flat out) forever.  When 429s appear it climbs until they
    stop and then converges just above the fastest rate that worked, because a
    poll spent on a 429 is a poll that cannot see a cross.

    Only query-class endpoints (/case, /securities, /securities/book, /limits)
    feed this.  Order insertions are a separate rate class on the RIT client, so
    a 429 on an order must never slow the polling loop down.
    """

    def __init__(self, base: float) -> None:
        self.base = max(0.0, base)
        self.interval = self.base
        self.floor = self.base
        self.last_limit = -1e9
        self.last_decay = 0.0
        self.hits = 0

    def note_rate_limit(self, now: float, observed_rate: float = 0.0) -> None:
        self.hits += 1
        if now - self.last_limit < max(self.interval, PACE_COOLDOWN):
            # Five threads share one rate limit, so one congestion event
            # arrives as a handful of 429s milliseconds apart.  Adapt once per
            # event, or the multiplicative increase compounds itself to the cap.
            self.last_limit = now
            self.last_decay = now
            return
        before = self.interval
        self.interval, self.floor = pace_on_rate_limit(
            self.interval, self.floor, self.base, now - self.last_limit,
            observed_rate)
        self.last_limit = now
        self.last_decay = now
        if self.interval > before:
            LOG.warning("PACING: 429 on a query endpoint -> poll interval "
                        "%.1f ms (floor %.1f ms). Pin --poll %.3f if this "
                        "keeps happening.",
                        self.interval * 1000.0, self.floor * 1000.0,
                        round(self.interval, 3))

    def current(self, now: float) -> float:
        """Seconds to sleep before the next poll.  Cheap: two compares when idle."""
        if self.interval <= self.base:
            return self.base
        if now - self.last_limit >= PACE_CLEAN and \
                now - self.last_decay >= PACE_DECAY_PERIOD:
            before = self.interval
            self.interval, self.floor = pace_decay(
                self.interval, self.floor, self.base)
            self.last_decay = now
            if self.interval <= self.base < before:
                LOG.info("PACING: quiet again, back to --poll %.3f", self.base)
        return self.interval


def remaining_wait(deadline: float, now: float, cap: float = BACKOFF_MAX_SECONDS) -> float:
    """Seconds left on an ``X-Wait-Until`` deadline, clamped to [0, cap]."""
    if deadline <= now:
        return 0.0
    return min(deadline - now, cap)


def strike_key(opp: Opportunity, top: tuple) -> tuple:
    """Identity of a displayed cross: direction, both prices, both sizes.

    If we strike a cross and the very next poll shows the same two prices with
    the same two sizes still on offer, that is not a second opportunity -- it is
    the client's quote view not having caught up with our own fills yet.  The
    real client lags by a couple of hundred milliseconds, which is long enough
    to re-strike the same cross five times in 20 ms and walk the book.
    """
    if opp.direction == DIR_BUY_M:
        return (opp.direction, top[1], top[5], top[3], top[7])
    return (opp.direction, top[6], top[0], top[8], top[2])


def should_strike(
    key: tuple,
    last_key: Optional[tuple],
    last_strike_at: float,
    now: float,
    cooldown: float = RESTRIKE_COOLDOWN,
) -> bool:
    """False while we are still inside the cooldown after any strike.

    The guard is deliberately time-based rather than key-based.  The live loss
    was seven strikes on one cross in 300 ms, and the reason a key check is not
    enough is that ``bid_size``/``ask_size`` are aggregate book sizes: they
    jitter on every unrelated order, so the "same" stale cross keeps arriving
    with a fresh key.  Until the client's view has certainly caught up with our
    own fills, no strike is a new opportunity.

    ``key`` and ``last_key`` are still reported so the caller can tell a genuine
    new cross from a stale repeat in the logs.
    """
    if last_strike_at <= 0.0:
        return True
    return (now - last_strike_at) >= cooldown


def net_position(pos_m: int, pos_a: int, mode: str = "auto") -> int:
    """True net exposure, whichever way the client reports positions.

    The real RIT client reports the **aggregated** CRZY position identically on
    both tickers, so summing them double-counts: a flat paired book reads as
    2x the net, the bot "flattens" twice what it holds, creates real exposure
    the other way, and spirals.  Equal positions on both legs are the signature
    of aggregated reporting -- a paired arb keeps the legs opposite, so equal
    and non-zero cannot be per-leg.
    """
    if mode == "aggregated":
        return int(pos_m)
    if mode == "per-leg":
        return int(pos_m) + int(pos_a)
    return int(pos_m) if pos_m == pos_a else int(pos_m) + int(pos_a)


def gross_position(pos_m: int, pos_a: int, mode: str = "auto") -> int:
    """Gross exposure under the same reporting caveat as :func:`net_position`."""
    if mode == "aggregated" or (mode == "auto" and pos_m == pos_a):
        return abs(int(pos_m))
    return abs(int(pos_m)) + abs(int(pos_a))


def flatten_confirmed(
    net: int,
    pending: int,
    pending_since: float,
    now: float,
    min_age: float = FLATTEN_CONFIRM_SECONDS,
) -> bool:
    """True only when the same non-zero net has been visible long enough.

    Positions lag fills on the real client, so a net read once is very often an
    artefact of a hedge that has already gone through.  Acting on it is how a
    flatten turns into a spiral.
    """
    if net == 0 or net != pending:
        return False
    return (now - pending_since) >= min_age


def budget_delay(
    stamps: Sequence[float],
    rate: float,
    reserve: float,
    n: int,
    now: float,
) -> float:
    """Seconds until ``n`` more requests fit under ``rate - reserve`` per second.

    ``stamps`` are the times of requests already made, any order, oldest first.
    This is a sliding one-second window rather than a leaky bucket because that
    is exactly how the RIT client counts: a bucket with a burst allowance can
    put twice the limit into one second and still call itself compliant.

    ``reserve`` is the part of the budget polls are not allowed to touch, so an
    order insertion always has room and is never the request that gets refused.
    """
    if rate <= 0:
        return 0.0
    usable = rate - reserve
    if usable < 1.0:
        usable = 1.0
    cut = now - 1.0
    recent = [t for t in stamps if t > cut]
    over = len(recent) + int(n) - int(usable)
    if over <= 0:
        return 0.0
    if over > len(recent):
        return 1.0                      # even an empty window cannot fit it
    # Wait for the `over`-th oldest request in the window to age out.
    return max(0.0, recent[over - 1] + 1.0 - now)


def budget_poll_interval(
    rate: float,
    reserve: float,
    overhead: float = BUDGET_OVERHEAD,
    floor: float = 0.0,
) -> float:
    """Poll spacing implied by a request budget, so --poll needs no tuning.

    Everything the bot does costs a request, so the sustainable polling rate is
    the budget minus the reserve kept for orders minus the fixed overhead of the
    case and trader polls.  ``floor`` is the user's ``--poll``, which still wins
    if it is slower.
    """
    if rate <= 0:
        return floor
    usable = rate - reserve - overhead
    if usable < 0.5:
        usable = 0.5
    return max(floor, 1.0 / usable)


def reducing_direction(pos_m: int, pos_a: int, size: int = 1) -> Optional[str]:
    """Which paired direction *reduces* gross exposure, or None if neither does.

    Gross is |pos_M| + |pos_A|.  A paired arb moves one leg up and the other
    down, so it shrinks gross only when the two legs have opposite signs -- the
    normal state after a run of one-sided crosses.  When both legs sit on the
    same side (or one is flat) a paired trade just shifts inventory between the
    exchanges and gross is unchanged or worse, so there is nothing to prefer.
    """
    before = abs(pos_m) + abs(pos_a)
    buy_m = abs(pos_m + size) + abs(pos_a - size)
    buy_a = abs(pos_m - size) + abs(pos_a + size)
    if buy_m < before and buy_m <= buy_a:
        return DIR_BUY_M
    if buy_a < before:
        return DIR_BUY_A
    return None


def reducing_sides(pos_m: int, pos_a: int) -> Dict[Tuple[str, str], int]:
    """Resting quotes that would shrink gross, mapped to the size that flattens.

    A long position is reduced by a resting SELL and a short by a resting BUY,
    and there is no point offering more than the position itself.
    """
    out: Dict[Tuple[str, str], int] = {}
    for ticker, pos in ((TICKER_M, pos_m), (TICKER_A, pos_a)):
        if pos > 0:
            out[(ticker, "SELL")] = pos
        elif pos < 0:
            out[(ticker, "BUY")] = -pos
    return out


def window_is_clean(slippage: float, leg_risk: int) -> bool:
    """A window with no leg-risk event and no adverse average slippage."""
    return leg_risk <= 0 and slippage >= 0.0


def decide_mode(
    mode: str,
    sig: "Signals",
    slip_threshold: float,
    min_trades: int,
    unwind_threshold: float,
    unwind_exit: float,
    clean_streak: int,
    clean_needed: int = CONSERVATIVE_CLEAN_WINDOWS,
) -> Tuple[str, str]:
    """The regime state machine.  Pure: snapshot in, (mode, reason) out.

    Priority order matters.  Running out of balance-sheet is an immediate,
    mechanical problem -- it stops us trading at all -- so UNWIND outranks
    CONSERVATIVE, which is only about execution quality.  Both entries are
    deliberately easier than their exits (hysteresis): one bad window flips us
    defensive, two clean ones are needed to come back, and the unwind exit
    threshold sits well below its entry.
    """
    if sig.gross_util >= unwind_threshold:
        if mode != MODE_UNWIND:
            return MODE_UNWIND, ("gross_util=%.2f >= %.2f pos_M=%+d pos_A=%+d"
                                 % (sig.gross_util, unwind_threshold,
                                    sig.pos_m, sig.pos_a))
        return MODE_UNWIND, ""

    freed = ""
    if mode == MODE_UNWIND:
        if sig.gross_util > unwind_exit:
            return MODE_UNWIND, ""                  # still unwinding
        # Free again; fall through and pick between the other two modes.
        freed = ("gross_util=%.2f <= %.2f pos_M=%+d pos_A=%+d"
                 % (sig.gross_util, unwind_exit, sig.pos_m, sig.pos_a))
        mode = MODE_AGGRESSIVE

    bad_slippage = sig.trades >= min_trades and sig.slippage < slip_threshold
    if bad_slippage or sig.leg_risk > 0:
        if mode != MODE_CONSERVATIVE:
            why = ("slippage=%.4f < %.4f on %d fills"
                   % (sig.slippage, slip_threshold, sig.trades)) if bad_slippage \
                else "leg_risk=%d in the window" % sig.leg_risk
            return MODE_CONSERVATIVE, why
        return MODE_CONSERVATIVE, ""

    if mode == MODE_CONSERVATIVE:
        if clean_streak >= clean_needed:
            return MODE_AGGRESSIVE, ("%d clean windows (slippage=%+.4f)"
                                     % (clean_streak, sig.slippage))
        return MODE_CONSERVATIVE, ""
    return MODE_AGGRESSIVE, freed


def infer_tick(*prices: Optional[float]) -> float:
    """Tick size implied by the quoted prices: 2 decimals => 0.01, 3 => 0.001."""
    decimals = 2
    for p in prices:
        if p is None:
            continue
        text = ("%.6f" % float(p)).rstrip("0")
        frac = text.split(".", 1)[1] if "." in text else ""
        decimals = max(decimals, len(frac))
    decimals = min(decimals, 4)
    return round(10.0 ** (-decimals), 6)


def quote_target(
    side: str,
    ref_price: Optional[float],
    own_bid: Optional[float],
    own_ask: Optional[float],
    tick: float,
) -> Optional[float]:
    """Price for a resting quote, or None if it must not be posted.

    ``side`` is "SELL" or "BUY"; ``ref_price`` is the *other* exchange's best
    ask (when we sell) or best bid (when we buy).  We want the incoming
    crossing order to hit us first, so we sit one tick beyond the other
    exchange's touch - but only if that is at or inside our own exchange's
    spread and does not cross our own book.
    """
    if ref_price is None:
        return None
    if side == "SELL":
        target = round(ref_price + tick, 6)
        if own_bid is not None and target <= own_bid + 1e-9:
            return None                      # would cross our own book
        if own_ask is not None and target > own_ask + 1e-9:
            return None                      # worse than our own best offer
        return target
    if side == "BUY":
        target = round(ref_price - tick, 6)
        if own_ask is not None and target >= own_ask - 1e-9:
            return None
        if own_bid is not None and target < own_bid - 1e-9:
            return None
        return target
    return None


def should_requote(
    resting_price: Optional[float],
    target: Optional[float],
    tick: float,
    tolerance: int,
    last_action_at: float,
    now: float,
    interval: float,
) -> bool:
    """True when the resting quote should be cancelled and re-posted.

    False when nothing is resting and there is no target, when the resting
    price is still within ``tolerance`` ticks of the target, or when the
    cancel/replace throttle has not elapsed.
    """
    if now - last_action_at < interval:
        return False
    if resting_price is None:
        return target is not None
    if target is None:
        return True
    return abs(resting_price - target) > tolerance * tick + 1e-9


def passive_fill_delta(expected: int, actual: int) -> int:
    """Shares filled passively on one ticker: actual position minus our own.

    Positive means a resting BUY was hit (we are longer than our arb legs
    account for) and must be hedged by SELLing the same quantity on the other
    exchange; negative means a resting SELL was lifted.
    """
    return int(actual) - int(expected)


class RequestBudget:
    """One request-per-second budget shared by every thread of the bot.

    The RIT client counts requests across all endpoints, so polls, case checks,
    book fetches, order insertions, cancels and trader polls all come out of the
    same allowance.  Two rules make that survivable:

    * **Orders never wait.**  ``spend_priority`` records the request and returns
      immediately, overdrawing the window if it has to.  A missed cross costs
      real money; a slightly late poll costs nothing.
    * **Polls keep a reserve.**  ``spend`` blocks until the request fits under
      ``rate - reserve``, so there is always room for a paired strike and an
      order is never the request that comes back 429.
    """

    def __init__(self, rate: float, reserve: float = RATE_RESERVE_DEFAULT) -> None:
        self.rate = float(rate or 0.0)
        self.reserve = float(reserve)
        if self.rate and self.reserve >= self.rate:
            self.reserve = max(0.0, self.rate - 1.0)
        self._stamps: deque = deque()
        self._lock = threading.Lock()
        self.spent = 0
        self.overdrawn = 0          # priority requests made with no budget left
        self.waited = 0.0           # total seconds polls spent waiting

    @property
    def enabled(self) -> bool:
        return self.rate > 0.0

    def _trim(self, now: float) -> None:
        stamps = self._stamps
        cut = now - 1.0
        while stamps and stamps[0] <= cut:
            stamps.popleft()

    def spend_priority(self, n: int = 1) -> None:
        """Record ``n`` requests that are going out no matter what."""
        if not self.rate:
            return
        now = time.time()
        with self._lock:
            self._trim(now)
            if len(self._stamps) + n > self.rate:
                self.overdrawn += 1
            for _ in range(n):
                self._stamps.append(now)
            self.spent += n

    def spend(self, n: int = 1, max_wait: Optional[float] = None) -> bool:
        """Block until ``n`` requests fit under the budget, then record them.

        Returns False without spending anything if that would take longer than
        ``max_wait`` -- which is how depth fetches get skipped when the budget
        is tight rather than delaying the next poll.
        """
        if not self.rate:
            return True
        deadline = None
        while True:
            now = time.time()
            with self._lock:
                self._trim(now)
                delay = budget_delay(self._stamps, self.rate, self.reserve, n, now)
                if delay <= 0.0:
                    for _ in range(n):
                        self._stamps.append(now)
                    self.spent += n
                    return True
            if max_wait is not None and delay > max_wait:
                return False
            if deadline is None:
                deadline = now + (max_wait if max_wait is not None else 2.0)
            elif now >= deadline:
                return False
            self.waited += min(delay, 0.25)
            time.sleep(min(delay, 0.25))

    def can_spend(self, n: int = 1) -> bool:
        """True if ``n`` requests could go out right now without waiting."""
        if not self.rate:
            return True
        now = time.time()
        with self._lock:
            self._trim(now)
            return budget_delay(self._stamps, self.rate, self.reserve, n, now) <= 0.0


# --------------------------------------------------------------------------- #
# REST client - stdlib http.client, one keep-alive connection per thread
# --------------------------------------------------------------------------- #


class _ConnPool:
    """One persistent HTTP connection per calling thread.

    The bot uses five threads (main poll, two order-leg threads, two book
    threads) and each gets its own socket, so a book fetch can never queue
    behind an order insertion.
    """

    def __init__(self, host: str, port: int, timeout: float) -> None:
        self.host = host
        self.port = port
        self.timeout = timeout
        self._local = threading.local()

    def get(self) -> http.client.HTTPConnection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = http.client.HTTPConnection(self.host, self.port,
                                              timeout=self.timeout)
            conn.connect()
            try:
                conn.sock.setsockopt(6, 1, 1)     # IPPROTO_TCP, TCP_NODELAY
            except Exception:
                pass
            self._local.conn = conn
        return conn

    def drop(self) -> None:
        conn = getattr(self._local, "conn", None)
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
            self._local.conn = None

    def close_all(self) -> None:
        self.drop()


class RitClient:
    """Thin, defensive wrapper around the RIT Client REST API.

    Never raises out of a call: every public method returns None / empty on
    failure so the hot loop cannot die.
    """

    def __init__(self, cfg: Config, tally: Tally,
                 budget: "Optional[RequestBudget]" = None) -> None:
        self.cfg = cfg
        self.tally = tally
        self.budget = budget if budget is not None else RequestBudget(0.0)
        self.guard = NetGuard(cfg.position_mode)
        parsed = urlparse(cfg.base_url)
        self.base_path = parsed.path.rstrip("/") or ""
        host = parsed.hostname or "localhost"
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        if parsed.scheme == "https":  # pragma: no cover - RIT is local http
            raise RuntimeError("https base URLs are not supported; RIT is local http")
        self._pool = _ConnPool(host, port, HTTP_TIMEOUT)
        self._headers = {
            "X-API-Key": cfg.api_key,
            "Accept": "application/json",
            "Connection": "keep-alive",
        }
        # Precomputed paths: no string formatting on the hot path.
        self._p_case = self.base_path + "/case"
        self._p_securities = self.base_path + "/securities"
        self._p_limits = self.base_path + "/limits"
        self._p_book = {
            t: self.base_path + "/securities/book?ticker=" + t + "&limit=20"
            for t in TICKERS
        }
        self._p_market = {
            (t, a): (self.base_path + "/orders?ticker=" + t +
                     "&type=MARKET&action=" + a + "&quantity=")
            for t in TICKERS for a in ("BUY", "SELL")
        }
        # Adaptive pacing, read by the main loop.  Orders are a separate rate
        # class on the RIT client, so only query endpoints feed it.
        # With a budget the poll spacing follows from it; --poll is the floor.
        self.pacer = Pacer(budget_poll_interval(
            self.budget.rate, self.budget.reserve, floor=cfg.poll)
            if self.budget.enabled else cfg.poll)
        self._order_prefixes = (self.base_path + "/orders",
                                self.base_path + "/commands")
        # Rolling one-second count of query-class requests, so that when a 429
        # arrives we know how fast we were actually asking.
        self._q_count = 0
        self._q_window = time.time()
        self._q_rate = 0.0
        # X-Wait-Until deadlines, per ticker.
        self.wait_until: Dict[str, float] = {t: 0.0 for t in TICKERS}

    # -- low level ---------------------------------------------------------- #

    def _raw(self, method: str, path: str):
        """One request on this thread's connection.  Returns (status, resp, body)."""
        for attempt in (0, 1):
            try:
                conn = self._pool.get()
                hdrs = self._headers
                if method in ("DELETE", "POST", "PUT"):
                    hdrs = dict(self._headers)
                    hdrs["Content-Length"] = "0"
                conn.request(method, path, headers=hdrs)
                resp = conn.getresponse()
                body = resp.read()
                if resp.will_close:
                    self._pool.drop()
                return resp.status, resp, body
            except Exception as exc:
                self._pool.drop()          # stale keep-alive or a real failure
                if attempt:
                    self.tally.errors += 1
                    LOG.warning("%s %s failed: %r", method, path, exc)
                    return None
        return None

    def _note_query(self, now: float) -> float:
        """Count one query request and return our current requests/second."""
        self._q_count += 1
        elapsed = now - self._q_window
        if elapsed >= 1.0:
            self._q_rate = self._q_count / elapsed
            self._q_count = 0
            self._q_window = now
            return self._q_rate
        if elapsed > 0.2:
            return max(self._q_rate, self._q_count / elapsed)
        return self._q_rate

    def _request(self, method: str, path: str, with_response: bool = False,
                 max_wait: Optional[float] = None):
        """Return parsed JSON (optionally with the HTTPResponse), or None.

        Every request is charged to the shared budget.  Orders are charged but
        never delayed; everything else waits for room above the reserve, and
        gives up rather than queue if ``max_wait`` is set.
        """
        is_order = path.startswith(self._order_prefixes)
        if is_order:
            self.budget.spend_priority()
        elif not self.budget.spend(1, max_wait):
            return None
        rate = 0.0 if is_order else self._note_query(time.time())
        for attempt in range(MAX_RETRIES):
            got = self._raw(method, path)
            if attempt:
                # A retry is another request against the same allowance.
                self.budget.spend_priority() if is_order else self.budget.spend(1)
            if got is None:
                time.sleep(min(0.02 * (attempt + 1), BACKOFF_MAX_SECONDS))
                continue
            status, resp, body = got

            if status == 200:
                try:
                    payload = json.loads(body)
                except ValueError:
                    self.tally.errors += 1
                    LOG.error("%s %s returned non-JSON body", method, path)
                    return None
                return (payload, resp) if with_response else payload

            if status == 429:
                self.tally.rate_limit_hits += 1
                if is_order:
                    # The expensive kind: a cross we saw and could not take.
                    self.tally.order_429 += 1
                wait = _wait_seconds(resp, body)
                if not is_order:
                    # Query class: back off once, widen the poll interval, and
                    # give up on THIS request.  Retrying a /securities poll in
                    # place just blocks the loop for seconds; the next
                    # iteration will read fresher quotes anyway.
                    self.pacer.note_rate_limit(time.time(), rate)
                    # Respect Retry-After, but never sleep longer than the
                    # widest interval we would ever pace at: under a sliding
                    # window that wait is the time for the whole window to
                    # drain (up to a second), and a second asleep is a second
                    # of crosses unseen.  The pacer has already widened the
                    # cadence, so a shorter nap is not hammering.
                    time.sleep(min(wait, max(self.pacer.interval, PACE_MAX)))
                    return None
                time.sleep(min(wait, BACKOFF_MAX_SECONDS))
                continue

            if status == 401:
                LOG.error("401 UNAUTHORIZED - check the API key (X-API-Key).")
                return None

            self.tally.errors += 1
            LOG.warning("%s %s -> HTTP %d %s", method, path, status, body[:200])
            return None
        return None

    # -- endpoints ---------------------------------------------------------- #

    def get_case(self) -> Optional[dict]:
        """GET /case -> {status, tick, period, ticks_per_period, ...}"""
        data = self._request("GET", self._p_case)
        return data if isinstance(data, dict) else None

    def get_top(self) -> Optional[tuple]:
        """The hot path: one GET /securities, parsed into a flat tuple.

        Returns (bid_m, ask_m, bid_size_m, ask_size_m, pos_m,
                 bid_a, ask_a, bid_size_a, ask_size_a, pos_a) or None.
        No dataclasses, no dicts, only the six fields per ticker we use.
        """
        data = self._request("GET", self._p_securities)
        if type(data) is not list:
            return None
        m = a = None
        for row in data:
            t = row.get("ticker")
            if t == TICKER_M:
                m = row
            elif t == TICKER_A:
                a = row
        if m is None or a is None:
            return None
        return (
            m.get("bid"), m.get("ask"), m.get("bid_size") or 0,
            m.get("ask_size") or 0, int(m.get("position") or 0),
            a.get("bid"), a.get("ask"), a.get("bid_size") or 0,
            a.get("ask_size") or 0, int(a.get("position") or 0),
        )

    def get_securities(self) -> Dict[str, Quote]:
        """GET /securities -> {ticker: Quote} for our two tickers."""
        data = self._request("GET", self._p_securities)
        out: Dict[str, Quote] = {}
        if not isinstance(data, list):
            return out
        for row in data:
            try:
                ticker = row["ticker"]
            except (TypeError, KeyError):
                continue
            if ticker not in TICKERS:
                continue
            out[ticker] = Quote(
                ticker=ticker,
                bid=_as_float(row.get("bid")),
                ask=_as_float(row.get("ask")),
                bid_size=_as_int(row.get("bid_size")),
                ask_size=_as_int(row.get("ask_size")),
                position=_as_int(row.get("position")),
            )
        return out

    def get_book(self, ticker: str, limit: int = 20,
                 max_wait: Optional[float] = None) -> Tuple[List[Level], List[Level]]:
        """GET /securities/book -> (bids desc, asks asc) as aggregated levels.

        Book entries are Order objects; the resting size is
        ``quantity - quantity_filled``.
        """
        path = self._p_book.get(ticker)
        if path is None:
            path = "%s/securities/book?%s" % (
                self.base_path, urlencode({"ticker": ticker, "limit": limit}))
        data = self._request("GET", path, max_wait=max_wait)
        if not isinstance(data, dict):
            return [], []
        # The real client returns "bids"/"asks"; the swagger spec says
        # "bid"/"ask".  Accept both -- reading the wrong one silently returned
        # an empty book, and every depth path then fell back to the aggregate
        # size fields, which is what sized the market orders that bled.
        raw_bids = data.get("bids")
        if raw_bids is None:
            raw_bids = data.get("bid")
        raw_asks = data.get("asks")
        if raw_asks is None:
            raw_asks = data.get("ask")
        if raw_bids is None and raw_asks is None:
            LOG.error("GET /securities/book for %s had neither bids/asks nor "
                      "bid/ask: %s", ticker, sorted(data)[:6])
            return [], []
        return _aggregate(raw_bids, True), _aggregate(raw_asks, False)

    def submit_market_order(self, ticker: str, action: str, quantity: int) -> Optional[dict]:
        """POST /orders with type=MARKET.  Returns the Order dict, or None."""
        if quantity <= 0:
            return None
        prefix = self._p_market.get((ticker, action))
        if prefix is None:
            return None
        got = self._request("POST", prefix + str(int(quantity)), with_response=True)
        if got is None:
            return None
        payload, resp = got
        self._note_wait_until(ticker, resp)
        return payload if isinstance(payload, dict) else None

    def submit_limit_order(self, ticker: str, action: str, quantity: int,
                           price: float) -> Optional[dict]:
        """POST /orders with type=LIMIT.  Returns the Order dict, or None."""
        if quantity <= 0:
            return None
        path = "%s/orders?%s" % (self.base_path, urlencode({
            "ticker": ticker, "type": "LIMIT", "quantity": int(quantity),
            "action": action, "price": round(float(price), 4),
        }))
        got = self._request("POST", path, with_response=True)
        if got is None:
            return None
        payload, resp = got
        self._note_wait_until(ticker, resp)
        return payload if isinstance(payload, dict) else None

    def cancel_order(self, order_id: int) -> bool:
        res = self._request("DELETE", "%s/orders/%d" % (self.base_path, int(order_id)))
        return isinstance(res, dict) and bool(res.get("success", True))

    def cancel_all(self) -> Optional[dict]:
        res = self._request("POST", self.base_path + "/commands/cancel?all=1")
        return res if isinstance(res, dict) else None

    def get_open_orders(self) -> List[dict]:
        res = self._request("GET", self.base_path + "/orders?status=OPEN")
        return res if isinstance(res, list) else []

    def get_trader(self) -> Optional[dict]:
        """GET /trader -> {trader_id, nlv, ...}.  Diagnostic only, once per
        regime interval; never on the hot path and never a trigger."""
        data = self._request("GET", self.base_path + "/trader")
        return data if isinstance(data, dict) else None

    def get_limits(self) -> Optional[list]:
        data = self._request("GET", self._p_limits)
        return data if isinstance(data, list) else None

    def close(self) -> None:
        self._pool.close_all()

    # -- helpers ------------------------------------------------------------ #

    def _note_wait_until(self, ticker: str, resp) -> None:
        try:
            raw = resp.getheader("X-Wait-Until")
        except Exception:
            return
        if not raw:
            return
        try:
            wait = float(raw)
        except (TypeError, ValueError):
            return
        if wait > 0:
            self.wait_until[ticker] = time.time() + wait


def _wait_seconds(resp, body: bytes) -> float:
    """Seconds to sleep after a 429, from Retry-After header or `wait` body."""
    wait = None
    try:
        header = resp.getheader("Retry-After")
    except Exception:
        header = None
    if header:
        try:
            wait = float(header)
        except (TypeError, ValueError):
            wait = None
    if wait is None:
        try:
            wait = float(json.loads(body).get("wait"))
        except Exception:
            wait = None
    if wait is None or wait < 0:
        wait = 0.1
    return min(wait, BACKOFF_MAX_SECONDS)


def _as_float(value) -> Optional[float]:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _as_int(value) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0


def _aggregate(orders, reverse: bool) -> List[Level]:
    """Collapse a list of book Orders into price levels with remaining size."""
    if not isinstance(orders, list):
        return []
    buckets: Dict[float, int] = {}
    for o in orders:
        if not isinstance(o, dict):
            continue
        price = _as_float(o.get("price"))
        if price is None:
            continue
        remaining = _as_int(o.get("quantity")) - _as_int(o.get("quantity_filled"))
        if remaining <= 0:
            continue
        buckets[price] = buckets.get(price, 0) + remaining
    return [
        Level(price=p, size=s)
        for p, s in sorted(buckets.items(), key=lambda kv: kv[0], reverse=reverse)
    ]


class NetGuard:
    """Owns the answer to "what is our net exposure, and is it real?"

    Two separate hazards, both seen live:

    * the client reports the aggregated CRZY position on *both* tickers, so
      summing them double-counts and every flatten overshoots by 2x;
    * positions lag fills, so a net read once is usually a hedge in flight.

    Everything that needs a net goes through here, and a flatten only fires on
    a net that has survived two polls at least ``FLATTEN_CONFIRM_SECONDS``
    apart.
    """

    def __init__(self, mode: str = "auto",
                 min_age: float = FLATTEN_CONFIRM_SECONDS) -> None:
        self.mode = mode
        self.min_age = min_age
        self.pending = 0
        self.pending_since = 0.0
        self.locked_until = 0.0
        self.lockout = max(0.6, 2.0 * min_age)
        self.aggregated: Optional[bool] = (
            True if mode == "aggregated" else False if mode == "per-leg" else None)
        self._announced = mode != "auto"

    def net(self, pos_m: int, pos_a: int) -> int:
        if self.mode == "auto" and not self._announced and (pos_m or pos_a):
            self.aggregated = (pos_m == pos_a)
            self._announced = True
            LOG.info("Position reporting detected as %s (CRZY_M=%+d CRZY_A=%+d). "
                     "%s  Override with --position-mode.",
                     "AGGREGATED - both tickers show the same total"
                     if self.aggregated else "per-leg",
                     pos_m, pos_a,
                     "Net is that number, not the sum of the two."
                     if self.aggregated else "Net is the sum of the two legs.")
        return net_position(pos_m, pos_a, self.mode)

    def gross(self, pos_m: int, pos_a: int) -> int:
        return gross_position(pos_m, pos_a, self.mode)

    def confirm(self, net: int, now: float) -> bool:
        """Record this observation; True when the net is old enough to act on."""
        if net == 0:
            self.pending = 0
            return False
        if now < self.locked_until:
            # A flatten just went out; the position read will not show it for
            # a few hundred ms.  Acting again on the same stale read is how the
            # flatten churned 14 times in 200 ms on the bench.
            return False
        if net != self.pending:
            self.pending = net
            self.pending_since = now
            return False
        if flatten_confirmed(net, self.pending, self.pending_since, now,
                             self.min_age):
            self.pending = 0
            self.locked_until = now + self.lockout
            return True
        return False


# --------------------------------------------------------------------------- #
# Execution
# --------------------------------------------------------------------------- #


def estimate_profit(
    opp: Opportunity,
    size: int,
    sell_bids: Sequence[Level],
    buy_asks: Sequence[Level],
    cfg: Config,
) -> float:
    """Expected profit on ``size`` shares, walking the books where we have them."""
    if sell_bids and buy_asks:
        _qty, profit = profitable_quantity(
            sell_bids, buy_asks, cfg.cost, cfg.min_profit, cap=size
        )
        return profit
    return size * opp.edge


def _fire_scarce_first(client: RitClient, opp: Opportunity, size: int,
                       cfg: Config, tally: Tally, tick, est: float,
                       stats: "Optional[RegimeStats]") -> int:
    """Hit the small crossing order first, then hedge exactly what filled.

    Seen live: firing both legs together fills the deep side (a ~100k level
    that is always there) and misses the crossing order (small, already being
    eaten by rivals), leaving a one-sided position that is reversed at a loss.
    Sequential legs cannot leave that imbalance: nothing is hedged that was
    not first filled, and the hedge goes into a level deep enough to absorb it.
    """
    if opp.scarce == "buy":
        t1, a1, p1 = opp.buy_ticker, "BUY", opp.ask_cheap
        t2, a2, p2 = opp.sell_ticker, "SELL", opp.bid_rich
    else:
        t1, a1, p1 = opp.sell_ticker, "SELL", opp.bid_rich
        t2, a2, p2 = opp.buy_ticker, "BUY", opp.ask_cheap

    res1 = client.submit_limit_order(t1, a1, size, p1)
    if not _order_ok(res1):
        LOG.error("SCARCE leg %s %d %s @%.2f rejected: %s", a1, size, t1, p1,
                  _order_status(res1))
        return 0
    filled = _as_int(res1.get("quantity_filled"))
    if filled < size and str(res1.get("status", "")).upper() == "OPEN":
        # Whatever did not fill instantly must NOT rest in the book: a resting
        # leg that fills later is an unhedged position (cost $4,700 live).
        # POST /commands/cancel?all=1 is the cancel path verified on the real
        # client; retry once if it does not confirm.
        cancelled = client.cancel_all()
        if not (cancelled and cancelled.get("cancelled_order_ids") is not None):
            time.sleep(0.05)
            cancelled = client.cancel_all()
        LOG.info("  leftover cancel: %s", cancelled)
        if not cancelled:
            LOG.error("  CANCEL FAILED for order %s - flatten will have to clean up",
                      res1.get("order_id"))
    if filled <= 0:
        LOG.info("CROSS tick=%s %s: scarce leg %s %s @%.2f filled nothing - cross gone",
                 tick, opp.direction, a1, t1, p1)
        return 0

    res2 = client.submit_market_order(t2, a2, filled)
    # The position read lags; do not let the flatten act on the half-done state.
    client.guard.pending = 0
    client.guard.locked_until = time.time() + client.guard.lockout
    if not _order_ok(res2):
        tally.leg_risk_events += 1
        LOG.error("HEDGE leg %s %d %s rejected (%s) - %d shares exposed, flatten will handle",
                  a2, filled, t2, _order_status(res2), filled)
        return filled

    got_est = est * (float(filled) / size) if size else 0.0
    tally.crosses_traded += 1
    tally.shares_traded += filled
    tally.est_profit += got_est
    if stats is not None:
        _note_leg(stats, res1, p1, filled, a1 == "BUY")
        _note_leg(stats, res2, p2, filled, a2 == "BUY")
    LOG.info("CROSS tick=%s %s scarce %s %s %d/%d @%.2f -> hedged %s %s %d vwap=%s est=$%.2f",
             tick, opp.direction, a1, t1, filled, size, p1, a2, t2, filled,
             res2.get("vwap"), got_est)
    return filled


def fire_pair(
    client: RitClient,
    legs: ThreadPoolExecutor,
    opp: Opportunity,
    size: int,
    cfg: Config,
    tally: Tally,
    tick,
    est: Optional[float] = None,
    stats: "Optional[RegimeStats]" = None,
) -> int:
    """Fire both legs simultaneously and repair any single-sided fill.

    Returns the size that went out (0 if nothing did).  The leg-risk reversal is
    deliberately synchronous: an unhedged position is the one thing worth
    blocking for.
    """
    if size <= 0:
        return 0
    if est is None:
        est = size * opp.edge

    if cfg.dry_run:
        tally.crosses_traded += 1
        tally.shares_traded += size
        tally.est_profit += est
        return size

    if cfg.legs == "scarce":
        return _fire_scarce_first(client, opp, size, cfg, tally, tick, est, stats)

    # Both legs at once: latency between them is the real risk in this case.
    if cfg.legs == "limit":
        # LIMIT at the crossed prices we saw.  A limit leg can never fill worse
        # than its price, so a book that moved under us costs a missed fill
        # instead of slippage -- which matters enormously when spreads blow out
        # to 50 cents as every bot in the room hits the book with market orders.
        f_buy: Future = legs.submit(client.submit_limit_order, opp.buy_ticker,
                                    "BUY", size, opp.ask_cheap)
        f_sell: Future = legs.submit(client.submit_limit_order, opp.sell_ticker,
                                     "SELL", size, opp.bid_rich)
    else:
        f_buy = legs.submit(client.submit_market_order, opp.buy_ticker, "BUY", size)
        f_sell = legs.submit(client.submit_market_order, opp.sell_ticker, "SELL", size)
    buy_res, buy_err = _resolve(f_buy)
    sell_res, sell_err = _resolve(f_sell)

    if cfg.legs == "limit":
        return _settle_limit_legs(client, opp, size, cfg, tally, tick, est,
                                  buy_res, sell_res, stats)

    buy_ok = _order_ok(buy_res)
    sell_ok = _order_ok(sell_res)

    if stats is not None:
        # Signed slippage per share: what we targeted at detection versus the
        # vwap we actually got.  Positive is better than expected.
        _note_leg(stats, buy_res, opp.ask_cheap, size, True)
        _note_leg(stats, sell_res, opp.bid_rich, size, False)

    if buy_ok and sell_ok:
        tally.crosses_traded += 1
        tally.shares_traded += size
        tally.est_profit += est
        LOG.info(
            "CROSS tick=%s %s buy %s @%.2f / sell %s @%.2f edge=%.4f size=%d est=$%.2f",
            tick, opp.direction, opp.buy_ticker, opp.ask_cheap,
            opp.sell_ticker, opp.bid_rich, opp.edge, size, est,
        )
        return size

    # ---- leg risk: exactly one side went through -------------------------- #
    tally.leg_risk_events += 1
    LOG.error(
        "LEG RISK! buy_ok=%s (%s) sell_ok=%s (%s) size=%d - reversing the filled leg",
        buy_ok, buy_err or _order_status(buy_res),
        sell_ok, sell_err or _order_status(sell_res), size,
    )
    if buy_ok and not sell_ok:
        filled = _filled_qty(buy_res, size)
        LOG.error("  reversing: SELL %d %s", filled, opp.buy_ticker)
        rev = client.submit_market_order(opp.buy_ticker, "SELL", filled)
        LOG.error("  reversal result: %s", _order_status(rev))
    elif sell_ok and not buy_ok:
        filled = _filled_qty(sell_res, size)
        LOG.error("  reversing: BUY %d %s", filled, opp.sell_ticker)
        rev = client.submit_market_order(opp.sell_ticker, "BUY", filled)
        LOG.error("  reversal result: %s", _order_status(rev))
    else:
        LOG.error("  both legs failed - no exposure taken, nothing to reverse")
    return 0


def _settle_limit_legs(client: RitClient, opp: Opportunity, size: int,
                       cfg: Config, tally: Tally, tick, est: float,
                       buy_res, sell_res, stats) -> int:
    """Let the limit legs rest briefly, cancel the rest, square any imbalance."""
    if cfg.limit_wait > 0:
        time.sleep(cfg.limit_wait)
    client.cancel_all()             # one request, budget-priority like an order

    buy_filled = _as_int(buy_res.get("quantity_filled")) if isinstance(buy_res, dict) else 0
    sell_filled = _as_int(sell_res.get("quantity_filled")) if isinstance(sell_res, dict) else 0
    if stats is not None:
        _note_leg(stats, buy_res, opp.ask_cheap, size, True)
        _note_leg(stats, sell_res, opp.bid_rich, size, False)

    done = min(buy_filled, sell_filled)
    if done > 0:
        tally.crosses_traded += 1
        tally.shares_traded += done
        tally.est_profit += est * (float(done) / size) if size else 0.0
        LOG.info("CROSS tick=%s %s buy %s @%.2f / sell %s @%.2f edge=%.4f "
                 "paired=%d of %d (limit legs)",
                 tick, opp.direction, opp.buy_ticker, opp.ask_cheap,
                 opp.sell_ticker, opp.bid_rich, opp.edge, done, size)

    imbalance = buy_filled - sell_filled
    if abs(imbalance) >= cfg.imbalance_min:
        tally.leg_risk_events += 1
        if imbalance > 0:           # long the cheap leg -> sell the rich one
            LOG.error("LEG IMBALANCE +%d on %s - selling %d %s at market",
                      imbalance, opp.buy_ticker, imbalance, opp.sell_ticker)
            res = client.submit_market_order(opp.sell_ticker, "SELL", imbalance)
        else:                       # short the rich leg -> buy the cheap one
            LOG.error("LEG IMBALANCE %d on %s - buying %d %s at market",
                      imbalance, opp.sell_ticker, -imbalance, opp.buy_ticker)
            res = client.submit_market_order(opp.buy_ticker, "BUY", -imbalance)
        LOG.error("  reversal result: %s", _order_status(res))
        # The position read will not show this reversal for a few hundred ms;
        # do not let the flatten act on the stale net and double it.
        client.guard.pending = 0
        client.guard.locked_until = time.time() + client.guard.lockout
    elif imbalance:
        # Too small to be worth a request; the confirmed flatten will mop it up.
        LOG.info("Leg imbalance of %d left for the flatten check", imbalance)
    return done


def _note_leg(stats: "RegimeStats", res: Optional[dict], targeted: float,
              requested: int, is_buy: bool) -> None:
    if not isinstance(res, dict):
        stats.note_fill(None, 0, requested)
        return
    filled = _as_int(res.get("quantity_filled"))
    vwap = _as_float(res.get("vwap"))
    slip = None
    if vwap is not None:
        slip = (targeted - vwap) if is_buy else (vwap - targeted)
    stats.note_fill(slip, filled, requested)


def _resolve(fut: Future) -> Tuple[Optional[dict], Optional[str]]:
    try:
        return fut.result(timeout=HTTP_TIMEOUT * (MAX_RETRIES + 1)), None
    except Exception as exc:
        return None, repr(exc)


def _order_ok(res: Optional[dict]) -> bool:
    """A submitted order counts as good unless it came back CANCELLED/None."""
    if not isinstance(res, dict):
        return False
    if "order_id" not in res:
        return False
    return str(res.get("status", "")).upper() != "CANCELLED"


def _order_status(res: Optional[dict]) -> str:
    if not isinstance(res, dict):
        return "no-response"
    return str(res.get("status") or res.get("code") or res)


def _filled_qty(res: Optional[dict], fallback: int) -> int:
    """Shares actually acquired, so we reverse exactly what we hold."""
    if isinstance(res, dict):
        q = _as_int(res.get("quantity_filled"))
        if q > 0:
            return q
        # A MARKET order that reports 0 filled is usually still fully done by the
        # time we read the response; fall back to the requested size.
        q = _as_int(res.get("quantity"))
        if q > 0:
            return q
    return fallback


def strike(
    client: RitClient,
    legs: ThreadPoolExecutor,
    books: ThreadPoolExecutor,
    opp: Opportunity,
    cfg: Config,
    tally: Tally,
    tick,
    pos_m: int,
    pos_a: int,
    depth: Optional[bool] = None,
    max_rounds: Optional[int] = None,
    min_profit: Optional[float] = None,
    stats: "Optional[RegimeStats]" = None,
) -> None:
    """First strike, then depth.

    The two MARKET orders and the two GET /securities/book requests all leave
    the machine at the same time, on four different sockets.  We do not wait for
    depth before trading - the cross is gone in a few hundred milliseconds and a
    round trip for the book is a round trip a competitor is using to fire.
    """
    if depth is None:
        depth = cfg.depth
    if max_rounds is None:
        max_rounds = cfg.max_rounds
    if min_profit is None:
        min_profit = cfg.min_profit
    if stats is not None:
        stats.note_detection(opp.top_size)

    if not depth or cfg.dry_run:
        # No book read: bid_size/ask_size from /securities are the AGGREGATE
        # size of the whole book side on the real client, not the top level, so
        # they cannot size an order.  Strike a small fixed size or nothing.
        size = capped_size(opp.direction, cfg.blind_size, pos_m, pos_a,
                           cfg.position_limit, cfg.margin, cfg.max_order)
        fired = fire_pair(client, legs, opp, size, cfg, tally, tick, None, stats)
        if stats is not None:
            stats.note_capture(fired)
        return

    # Depth first, always: the size of this trade comes from the real levels.
    f_sell_book = books.submit(client.get_book, opp.sell_ticker)
    f_buy_book = books.submit(client.get_book, opp.buy_ticker)
    sell_bids, _ = _resolve_books(f_sell_book)
    _, buy_asks = _resolve_books(f_buy_book)
    if not sell_bids or not buy_asks:
        return

    remaining, profit = profitable_quantity(sell_bids, buy_asks, cfg.cost,
                                            min_profit)
    if remaining <= 0:
        # The books say the cross is already gone; the quote view was stale.
        tally.stale_restrikes += 1
        return

    # The crossing order is the scarce side: whichever top level is smaller.
    # The other side is a ~100k ANON level at a normal price and will wait.
    opp.scarce = "sell" if sell_bids[0].size <= buy_asks[0].size else "buy"

    sign = 1 if opp.direction == DIR_BUY_M else -1
    for _round in range(max(1, max_rounds)):
        if remaining <= 0:
            return
        size = capped_size(opp.direction, remaining, pos_m, pos_a,
                           cfg.position_limit, cfg.margin, cfg.max_order)
        if size <= 0:
            if _round == 0:
                LOG.warning("Cross of %d shares skipped: no room under limits "
                            "(pos_M=%d pos_A=%d gross=%d)",
                            remaining, pos_m, pos_a, _gross(pos_m, pos_a))
            return
        now = time.time()
        wait = max(remaining_wait(client.wait_until[opp.buy_ticker], now),
                   remaining_wait(client.wait_until[opp.sell_ticker], now))
        if wait > 0:
            time.sleep(wait)
        est = profit * (float(size) / remaining) if remaining else 0.0
        got = fire_pair(client, legs, opp, size, cfg, tally, tick, est, stats)
        if _round == 0 and stats is not None:
            stats.note_capture(got)
        if got <= 0:
            return
        remaining -= got
        profit -= est
        pos_m += sign * got
        pos_a -= sign * got
        if got < size:
            # The scarce side gave less than we asked: the crossing order is
            # exhausted.  Another round is 3 wasted requests and a 20 ms delay.
            return


def _resolve_books(fut: Future) -> Tuple[List[Level], List[Level]]:
    try:
        return fut.result(timeout=HTTP_TIMEOUT * (MAX_RETRIES + 1))
    except Exception:
        return [], []


def flatten_from_top(client: RitClient, cfg: Config, tally: Tally,
                     top: tuple, guard: "NetGuard") -> None:
    """Flatten non-zero net exposure using the quotes we already have in hand.

    Called from the next poll iteration instead of a dedicated /securities
    round trip after every round: the positions are in that response anyway.
    """
    bid_m, _ask_m, _bsm, _asm, pos_m, bid_a, _ask_a, _bsa, _asa, pos_a = top
    net = guard.net(pos_m, pos_a)
    if abs(net) <= NET_TOLERANCE:
        return
    # Never send more than the limit itself: a doubled or stale reading must not
    # become a 40,000-share market order.
    if abs(net) > cfg.position_limit:
        LOG.error("FLATTEN refusing net=%d: larger than the position limit "
                  "(%d). Check --position-mode.", net, cfg.position_limit)
        return
    tally.flattens += 1
    if net > 0:                       # long overall -> sell where the bid is best
        action, qty = "SELL", net
        if bid_m is None and bid_a is None:
            LOG.error("FLATTEN net=%d but no usable bids", net)
            return
        ticker = TICKER_M if (bid_a is None or (bid_m is not None and bid_m >= bid_a)) \
            else TICKER_A
    else:                             # short overall -> buy where the ask is best
        action, qty = "BUY", -net
        ask_m, ask_a = top[1], top[6]
        if ask_m is None and ask_a is None:
            LOG.error("FLATTEN net=%d but no usable asks", net)
            return
        ticker = TICKER_M if (ask_a is None or (ask_m is not None and ask_m <= ask_a)) \
            else TICKER_A

    LOG.error("FLATTEN net=%d -> %s %d %s", net, action, qty, ticker)
    if cfg.dry_run:
        return
    for start in range(0, qty, cfg.max_order):
        chunk = min(cfg.max_order, qty - start)
        res = client.submit_market_order(ticker, action, chunk)
        LOG.error("  flatten result: %s", _order_status(res))


# --------------------------------------------------------------------------- #
# Passive quoting overlay (opt in, --quote)
# --------------------------------------------------------------------------- #


class RestingQuote:
    """One resting limit order we are trying to keep live."""

    __slots__ = ("ticker", "side", "order_id", "price", "size", "last_action")

    def __init__(self, ticker: str, side: str) -> None:
        self.ticker = ticker
        self.side = side
        self.order_id: Optional[int] = None
        self.price: Optional[float] = None
        self.size = 0
        self.last_action = 0.0


class Quoter:
    """Rest limit orders so the incoming crossing order executes against US.

    Every polling arb bot in the room is racing to *hit* a cross once it shows
    up.  A resting order that is already sitting at the right price wins that
    race by construction: the crossing order trades against it before anyone
    can react.  The fill is then hedged instantly with a MARKET order on the
    other exchange, which is where the edge is booked.

    Threading: the main loop never blocks on any of this.  It hands the poll
    snapshot to a single dedicated worker thread (its own socket) that owns all
    quote state and all quote/hedge order submission.  Because that thread is
    single, fill detection and order submission can never interleave with each
    other -- which matters enormously: a position read that predates one of our
    own in-flight orders looks exactly like a passive fill, and acting on it
    produces a runaway hedge loop.  Snapshots taken within ``SETTLE`` seconds of
    our last order are therefore ignored for fill-detection purposes.
    """

    SETTLE = 0.025      # a position read this fresh may not include our orders

    def __init__(self, client: RitClient, cfg: Config, tally: Tally,
                 worker: ThreadPoolExecutor) -> None:
        self.client = client
        self.cfg = cfg
        self.tally = tally
        self.worker = worker
        self.inflight: Optional[Future] = None
        self.quotes: Dict[Tuple[str, str], RestingQuote] = {
            (t, s): RestingQuote(t, s) for t in TICKERS for s in ("BUY", "SELL")
        }
        self.expected: Dict[str, int] = {t: 0 for t in TICKERS}
        self.primed = False
        self.paused = False
        self.last_reconcile = 0.0
        self.last_order_at = 0.0
        self.epoch = 0
        self.stopped = False
        # The regime monitor can switch quoting on for UNWIND alone, and can
        # restrict it to the sides that shrink gross.
        self.enabled = bool(cfg.quote)
        self.caps: Optional[Dict[Tuple[str, str], int]] = None
        self.tick = cfg.tick or DEFAULT_TICK

    # -- called from the main polling thread -------------------------------- #

    def settled(self, now: float) -> bool:
        """True when a position read now is guaranteed to include our orders."""
        return now - self.last_order_at >= self.SETTLE

    def stop(self) -> None:
        """Refuse any further quoting; the resting orders are cancelled after."""
        self.stopped = True
        self.enabled = False
        self.epoch += 1

    def enable(self) -> None:
        if not self.enabled and not self.stopped:
            self.enabled = True
            self.primed = False
            self.epoch += 1

    def disable(self) -> None:
        """Stop quoting and pull everything that is resting."""
        if not self.enabled:
            return
        self.enabled = False
        self.epoch += 1
        self.cancel_all()

    def restrict(self, caps: Optional[Dict[Tuple[str, str], int]]) -> None:
        """Limit quoting to these (ticker, side) pairs, each with a max size.

        ``None`` lifts the restriction.  Anything currently resting outside the
        new set is cancelled, because in UNWIND a quote on the expanding side is
        exactly the trade we are trying not to do.
        """
        self.caps = caps
        if caps is None:
            return
        for key, rq in self.quotes.items():
            if key not in caps and rq.order_id is not None:
                self.client.cancel_order(rq.order_id)
                self.tally.quotes_cancelled += 1
                rq.order_id, rq.price, rq.size = None, None, 0

    def on_poll(self, top: tuple, now: float) -> None:
        """Hand the snapshot to the quote thread.  Never blocks, never raises."""
        if self.stopped or not self.enabled:
            return
        if self.inflight is not None and not self.inflight.done():
            return
        try:
            self.inflight = self.worker.submit(self._work, top, now, self.epoch)
        except RuntimeError:                      # pool already shut down
            self.inflight = None

    def reprime(self) -> None:
        """Forget the expected positions; the next settled poll re-reads them.

        Called after the arb path trades, so its legs are never mistaken for a
        passive fill.
        """
        self.primed = False
        self.last_order_at = time.time()
        # Invalidate any snapshot already in flight on the quote thread: it
        # predates the arb legs and would be read as a giant passive fill.
        self.epoch += 1

    # -- everything below runs on the single quote worker thread ------------ #

    def _work(self, top: tuple, snap_at: float, epoch: int) -> None:
        try:
            if self.stopped or not self.enabled or epoch != self.epoch:
                return
            bid_m, ask_m, _bsm, _asm, pos_m, bid_a, ask_a, _bsa, _asa, pos_a = top
            if self.cfg.tick is None:
                self.tick = infer_tick(bid_m, ask_m, bid_a, ask_a)

            if self.settled(snap_at) and epoch == self.epoch:
                if not self.primed:
                    self.expected[TICKER_M] = pos_m
                    self.expected[TICKER_A] = pos_a
                    self.primed = True
                elif self.client.guard.aggregated:
                    # Per-leg fill detection is impossible when both tickers
                    # report the same aggregated number; quoting cannot be run
                    # safely, so stop rather than guess.
                    LOG.warning("QUOTE disabled: this client reports an "
                                "aggregated position, so passive fills cannot "
                                "be attributed to a leg.")
                    self.disable()
                    return
                elif not self._detect_fills(pos_m, pos_a, epoch) and \
                        self.client.guard.confirm(
                            self.client.guard.net(pos_m, pos_a), snap_at):
                    # No fill this pass and the snapshot has settled, so a
                    # non-zero net is real: repair it here, on the one thread
                    # that knows what is already in flight.
                    flatten_from_top(self.client, self.cfg, self.tally, top,
                                     self.client.guard)
                    self.last_order_at = time.time()
                    self.primed = False

            # Divergence guard: the whole premise is that the two books mirror.
            mid_m = _mid(bid_m, ask_m)
            mid_a = _mid(bid_a, ask_a)
            if mid_m is None or mid_a is None or \
                    abs(mid_m - mid_a) > self.cfg.max_divergence * self.tick + 1e-9:
                if not self.paused:
                    LOG.warning("QUOTE paused: mids diverged (%s vs %s)", mid_m, mid_a)
                    self.paused = True
                    self.cancel_all()
                return
            if self.paused:
                LOG.info("QUOTE resumed: mids back in line")
                self.paused = False

            if epoch != self.epoch:
                return
            if snap_at - self.last_reconcile >= OPEN_ORDER_POLL_SECONDS:
                self.last_reconcile = snap_at
                self._reconcile()

            # M quotes reference A's touch, and vice versa.
            self._maintain(TICKER_M, "SELL", ask_a, bid_m, ask_m, pos_m, pos_a, snap_at)
            self._maintain(TICKER_M, "BUY", bid_a, bid_m, ask_m, pos_m, pos_a, snap_at)
            self._maintain(TICKER_A, "SELL", ask_m, bid_a, ask_a, pos_m, pos_a, snap_at)
            self._maintain(TICKER_A, "BUY", bid_m, bid_a, ask_a, pos_m, pos_a, snap_at)
        except Exception:                          # never kill the quote thread
            LOG.exception("quote maintenance failed")

    def _maintain(self, ticker: str, side: str, ref: Optional[float],
                  own_bid: Optional[float], own_ask: Optional[float],
                  pos_m: int, pos_a: int, now: float) -> None:
        rq = self.quotes[(ticker, side)]
        cap = None
        if self.caps is not None:
            cap = self.caps.get((ticker, side))
            if cap is None:
                if rq.order_id is not None:       # restricted away: pull it
                    self.client.cancel_order(rq.order_id)
                    self.tally.quotes_cancelled += 1
                    rq.order_id, rq.price, rq.size = None, None, 0
                return
        target = quote_target(side, ref, own_bid, own_ask, self.tick)
        size = 0
        if target is not None:
            # A fill here gets hedged on the other exchange, i.e. the pair is
            # exactly one arb trade; size it with the same limit arithmetic.
            direction = DIR_BUY_M if (ticker == TICKER_M) == (side == "BUY") \
                else DIR_BUY_A
            # Every other quote we have resting could fill too, and each fill
            # drags a hedge behind it.  Reserve room for all of them.
            reserve = 2 * sum(q.size for k, q in self.quotes.items()
                              if k != (ticker, side))
            want = self.cfg.quote_size if cap is None else min(self.cfg.quote_size,
                                                               cap)
            size = capped_size(direction, want, pos_m, pos_a,
                               self.cfg.position_limit, self.cfg.margin + reserve,
                               self.cfg.max_order)
            if size <= 0:
                target = None

        if not should_requote(rq.price, target, self.tick, self.cfg.quote_tolerance,
                              rq.last_action, now, self.cfg.requote_interval):
            return
        rq.last_action = now
        if rq.order_id is not None:
            self.client.cancel_order(rq.order_id)
            self.tally.quotes_cancelled += 1
            rq.order_id, rq.price, rq.size = None, None, 0
        if target is None or size <= 0 or self.cfg.dry_run or self.stopped:
            return
        res = self.client.submit_limit_order(ticker, side, size, target)
        self.last_order_at = time.time()
        if not isinstance(res, dict) or res.get("order_id") is None:
            return
        self.tally.quotes_posted += 1
        filled = _as_int(res.get("quantity_filled"))
        if filled:
            # It crossed on entry: that is already a fill, hedge it now.
            self._hedge(ticker, side, filled)
        if str(res.get("status", "")).upper() == "OPEN":
            rq.order_id = int(res.get("order_id"))
            rq.price = target
            rq.size = size - filled

    def _detect_fills(self, pos_m: int, pos_a: int, epoch: int) -> bool:
        # The most a passive fill can ever be is everything we had resting on
        # that ticker.  Anything larger is our own untracked flow (a race with
        # the arb path, a manual trade in the client, a reconnect) and hedging
        # it would start a runaway loop, so we just re-baseline instead.
        plausible = 2 * max(self.cfg.quote_size, 0)
        acted = False
        for ticker, actual in ((TICKER_M, pos_m), (TICKER_A, pos_a)):
            if epoch != self.epoch:
                return acted
            delta = passive_fill_delta(self.expected[ticker], actual)
            if delta == 0:
                continue
            self.expected[ticker] = actual
            acted = True
            if abs(delta) > plausible:
                LOG.warning("QUOTE: %s position moved %+d, more than any quote "
                            "of ours (%d) - re-baselining, not hedging",
                            ticker, delta, plausible)
                self.cancel_all()
                continue
            self.tally.passive_fills += 1
            self.tally.passive_shares += abs(delta)
            # delta > 0: a resting BUY of ours was hit -> hedge by SELLing the
            # other exchange, and vice versa.
            side = "SELL" if delta > 0 else "BUY"
            other = TICKER_A if ticker == TICKER_M else TICKER_M
            LOG.info("PASSIVE FILL %s %+d -> hedge %s %d %s",
                     ticker, delta, side, abs(delta), other)
            # Whatever was resting on the filled side is (partly) gone.
            rq = self.quotes[(ticker, "BUY" if delta > 0 else "SELL")]
            rq.order_id, rq.price, rq.size = None, None, 0
            if self.cfg.dry_run:
                continue
            # A hedge is a paired arb trade: size it under the same limits.
            direction = DIR_BUY_M if (other == TICKER_M) == (side == "BUY") \
                else DIR_BUY_A
            qty = capped_size(direction, abs(delta), pos_m, pos_a,
                              self.cfg.position_limit, self.cfg.margin,
                              self.cfg.max_order)
            if qty < abs(delta):
                LOG.error("QUOTE: hedge of %d %s capped to %d by the position "
                          "limits", abs(delta), other, qty)
            if qty <= 0:
                continue
            res = self.client.submit_market_order(other, side, qty)
            self.last_order_at = time.time()
            if _order_ok(res):
                self.expected[other] += qty if side == "BUY" else -qty
            else:
                LOG.error("HEDGE FAILED for passive fill: %s", _order_status(res))
        return acted

    def _hedge(self, ticker: str, side: str, filled: int) -> None:
        other = TICKER_A if ticker == TICKER_M else TICKER_M
        hedge_side = "SELL" if side == "BUY" else "BUY"
        self.expected[ticker] += filled if side == "BUY" else -filled
        res = self.client.submit_market_order(other, hedge_side, filled)
        self.last_order_at = time.time()
        if _order_ok(res):
            self.expected[other] += filled if hedge_side == "BUY" else -filled
        else:
            LOG.error("HEDGE FAILED on entry fill: %s", _order_status(res))

    def _reconcile(self) -> None:
        live = set()
        for o in self.client.get_open_orders():
            oid = o.get("order_id")
            if oid is not None:
                live.add(int(oid))
        for rq in self.quotes.values():
            if rq.order_id is not None and rq.order_id not in live:
                rq.order_id, rq.price, rq.size = None, None, 0

    def cancel_all(self) -> None:
        """Pull every resting quote.  Safe to call from any thread, any time."""
        ids = [rq.order_id for rq in self.quotes.values() if rq.order_id is not None]
        for rq in self.quotes.values():
            rq.order_id, rq.price, rq.size = None, None, 0
        if self.cfg.dry_run:
            return
        if self.client.cancel_all() is None:
            for oid in ids:
                self.client.cancel_order(oid)
        self.last_order_at = time.time()
        self.tally.quotes_cancelled += len(ids)


def _mid(bid: Optional[float], ask: Optional[float]) -> Optional[float]:
    if bid is None or ask is None:
        return None
    return (bid + ask) / 2.0


# --------------------------------------------------------------------------- #
# Regime monitor
# --------------------------------------------------------------------------- #



class RegimeStats:
    """Execution-quality counters, fed from the trading path only.

    The no-cross iteration never touches this object: every field is written
    from ``strike`` / ``fire_pair``, i.e. only when we actually trade, and read
    once per regime interval.
    """

    __slots__ = ("w_slip", "w_slip_qty", "w_fills", "w_req", "w_filled",
                 "w_detected", "w_captured", "t_slip", "t_slip_qty", "t_fills")

    def __init__(self) -> None:
        self.t_slip = 0.0
        self.t_slip_qty = 0
        self.t_fills = 0
        self.reset_window()

    def reset_window(self) -> None:
        self.w_slip = 0.0
        self.w_slip_qty = 0
        self.w_fills = 0
        self.w_req = 0
        self.w_filled = 0
        self.w_detected = 0
        self.w_captured = 0

    def note_fill(self, slip: Optional[float], filled: int, requested: int) -> None:
        """One market leg came back.  ``slip`` is signed: positive is good."""
        if requested > 0:
            self.w_req += requested
        if filled > 0:
            self.w_filled += filled
        if slip is None or filled <= 0:
            return
        self.w_slip += slip * filled
        self.w_slip_qty += filled
        self.w_fills += 1
        self.t_slip += slip * filled
        self.t_slip_qty += filled
        self.t_fills += 1

    def note_detection(self, top_size: int) -> None:
        if top_size > 0:
            self.w_detected += top_size

    def note_capture(self, filled: int) -> None:
        if filled > 0:
            self.w_captured += filled

    # -- readers ------------------------------------------------------------ #

    def mean_slippage(self) -> float:
        return self.w_slip / self.w_slip_qty if self.w_slip_qty else 0.0

    def total_mean_slippage(self) -> float:
        return self.t_slip / self.t_slip_qty if self.t_slip_qty else 0.0

    def fill_ratio(self) -> float:
        return self.w_filled / float(self.w_req) if self.w_req else 1.0

    def capture_ratio(self) -> float:
        return self.w_captured / float(self.w_detected) if self.w_detected else 0.0


class RegimeMonitor:
    """Switches the bot between three modes on direct execution evidence.

    Every ``--regime-interval`` seconds it reads counters that the trading path
    has already accumulated, asks :func:`decide_mode` what to do, and republishes
    three knobs the main loop reads as plain locals: ``min_profit``, ``depth``
    and ``max_rounds``.  The no-cross path is untouched -- the monitor costs one
    timestamp comparison per iteration, which the loop already makes for the
    case poll.
    """

    def __init__(self, cfg: Config, tally: Tally, client: "RitClient",
                 quoter: "Optional[Quoter]", now: Optional[float] = None) -> None:
        self.cfg = cfg
        self.tally = tally
        self.client = client
        self.quoter = quoter
        self.stats = RegimeStats()
        self.mode = MODE_AGGRESSIVE
        self.tick = cfg.tick or DEFAULT_TICK
        self.slip_threshold = cfg.slip_threshold if cfg.slip_threshold is not None \
            else -self.tick
        self.clean_streak = 0
        self.seen_leg_risk = 0
        self.seen_429 = 0
        self.endgame = False
        self.next_check = (now or time.time()) + cfg.regime_interval
        # Knobs the main loop copies into locals.
        self.min_profit = cfg.min_profit
        self.depth = cfg.depth
        self.max_rounds = cfg.max_rounds

    # -- evaluation --------------------------------------------------------- #

    def snapshot(self, top: tuple) -> Signals:
        pos_m, pos_a = top[4], top[9]
        limit = max(1, self.cfg.position_limit)
        leg_risk = self.tally.leg_risk_events - self.seen_leg_risk
        limited = self.tally.rate_limit_hits - self.seen_429
        return Signals(
            trades=self.stats.w_fills,
            slippage=self.stats.mean_slippage(),
            fill_ratio=self.stats.fill_ratio(),
            capture_ratio=self.stats.capture_ratio(),
            gross_util=self.client.guard.gross(pos_m, pos_a) / float(limit),
            leg_risk=leg_risk,
            rate_limited=limited,
            pos_m=pos_m,
            pos_a=pos_a,
            total_slippage=self.stats.total_mean_slippage(),
            total_trades=self.stats.t_fills,
        )

    def evaluate(self, now: float, top: tuple) -> None:
        sig = self.snapshot(top)
        sig.nlv = self._nlv()

        if self.mode == MODE_CONSERVATIVE:
            self.clean_streak = self.clean_streak + 1 \
                if window_is_clean(sig.slippage, sig.leg_risk) else 0
        else:
            self.clean_streak = 0

        new_mode, reason = decide_mode(
            self.mode, sig, self.slip_threshold, self.cfg.regime_min_trades,
            self.cfg.unwind_threshold, self.cfg.unwind_exit, self.clean_streak)

        LOG.info("REGIME [%s] slip=%+.4f/sh fills=%d fill_ratio=%.2f "
                 "capture=%.2f gross_util=%.2f leg_risk=%d http429=%d "
                 "nlv=%s est=$%.2f",
                 self.mode, sig.slippage, sig.trades, sig.fill_ratio,
                 sig.capture_ratio, sig.gross_util, sig.leg_risk,
                 sig.rate_limited,
                 ("$%.2f" % sig.nlv) if sig.nlv is not None else "n/a",
                 self.tally.est_profit)
        if new_mode != self.mode:
            LOG.info("REGIME %s -> %s (%s)", self.mode, new_mode, reason)
            self.mode = new_mode
            self.clean_streak = 0

        self.tally.mode = self.mode
        self.seen_leg_risk = self.tally.leg_risk_events
        self.seen_429 = self.tally.rate_limit_hits
        self.stats.reset_window()
        self.next_check = now + self.cfg.regime_interval
        self.apply(top)

    def apply(self, top: tuple) -> None:
        """Republish the knobs and reconfigure the quoter for the current mode."""
        # UNWIND deliberately does NOT refuse the gross-expanding direction.
        # capped_size already sizes every trade down to the room left under the
        # limit and returns 0 when there is none, so refusing outright only
        # discards trades that were both profitable and permitted.  UNWIND's
        # whole behaviour is the one-sided passive quotes below.
        if self.mode == MODE_CONSERVATIVE:
            # Take the touch and nothing else: no book round trips, no follow-up
            # rounds walking into the depth that just cost us money, and a wider
            # hurdle so marginal crosses are left alone.
            self.min_profit = self.cfg.min_profit + self.tick
            self.depth = self.cfg.depth   # books are the only safe sizing source
            self.max_rounds = 1
        else:
            self.min_profit = self.cfg.min_profit
            self.depth = self.cfg.depth
            self.max_rounds = self.cfg.max_rounds

        if self.quoter is None:
            return
        if self.endgame:
            self._disable_quotes()
        elif self.mode == MODE_UNWIND:
            caps = reducing_sides(top[4], top[9])
            self.quoter.restrict(caps)
            self.quoter.enable()
        elif self.cfg.quote:
            self.quoter.restrict(None)
            self.quoter.enable()
        else:
            self._disable_quotes()

    def note_endgame(self, ticks_left: float) -> bool:
        """True the first time we cross into the end-of-case flatten window."""
        if self.endgame or ticks_left > self.cfg.flatten_at:
            return False
        self.endgame = True
        LOG.info("REGIME endgame: %.0f ticks left - cancelling quotes and "
                 "flattening net exposure (paired gross is fine to hold, it "
                 "nets to zero)", ticks_left)
        self._disable_quotes()
        return True

    # -- helpers ------------------------------------------------------------ #

    def _disable_quotes(self) -> None:
        if self.quoter is not None and self.quoter.enabled:
            self.quoter.disable()

    def _nlv(self) -> Optional[float]:
        data = self.client.get_trader()
        if not isinstance(data, dict):
            return None
        return _as_float(data.get("nlv"))


# --------------------------------------------------------------------------- #
# Main loop
# --------------------------------------------------------------------------- #


def main_loop(client: RitClient, cfg: Config, tally: Tally,
              legs: ThreadPoolExecutor, books: ThreadPoolExecutor,
              quoter: Optional[Quoter] = None,
              monitor: Optional[RegimeMonitor] = None) -> None:
    case = client.get_case()
    if case is None:
        LOG.error("Cannot reach %s/case - is the RIT client running with the API on?",
                  cfg.base_url)
        return
    LOG.info("Case '%s' status=%s tick=%s/%s period=%s",
             case.get("name"), case.get("status"), case.get("tick"),
             case.get("ticks_per_period"), case.get("period"))
    if not cfg.dry_run:
        limits = client.get_limits()
        if limits:
            LOG.info("Limits reported by the client: %s", limits)

    last_case_poll = time.time()
    last_tally = last_case_poll
    last_dry_key: Optional[tuple] = None
    last_dry_time = 0.0
    status = str(case.get("status", "")).upper()
    tick = case.get("tick")
    ticks_per_period = _as_int(case.get("ticks_per_period"))
    cost = cfg.cost
    min_profit = cfg.min_profit
    depth = cfg.depth
    max_rounds = cfg.max_rounds
    pacer = client.pacer
    stats = monitor.stats if monitor is not None else None
    guard = client.guard
    last_key: Optional[tuple] = None
    last_strike_at = 0.0
    restrike_cooldown = cfg.restrike_cooldown
    post_strike_sleep = cfg.post_strike_sleep

    was_active = status == "ACTIVE"
    if not was_active:
        LOG.info("Case is %s - waiting for it to start (Ctrl-C to quit).", status)

    while True:
        now = time.time()

        if now - last_case_poll >= CASE_POLL_SECONDS:
            last_case_poll = now
            fresh = client.get_case()
            if fresh is not None:
                case = fresh
                status = str(case.get("status", "")).upper()
                tick = case.get("tick")
                ticks_per_period = _as_int(case.get("ticks_per_period")) or ticks_per_period
                if status == "ACTIVE" and not was_active:
                    was_active = True
                    LOG.info("Case ACTIVE at tick %s - trading.", tick)
                if status == "STOPPED" and (was_active or _as_int(tick) > 0):
                    # STOPPED at tick 0 before we ever saw ACTIVE is just the
                    # case not having started yet; keep waiting for the start.
                    LOG.info("Case STOPPED at tick %s - exiting.", tick)
                    return
                if ticks_per_period and _as_int(tick) >= ticks_per_period:
                    LOG.info("Reached the final tick (%s) - exiting.", tick)
                    return
                if monitor is not None and ticks_per_period:
                    # Counted in TICKS: the trial advanced about one tick every
                    # four seconds, so seconds-left was wrong by 4x.
                    monitor.note_endgame(ticks_per_period - _as_int(tick))

        if now - last_tally >= TALLY_INTERVAL_SECONDS:
            last_tally = now
            tally.poll_ms = pacer.interval * 1000.0
            LOG.info(tally.summary())

        if status != "ACTIVE":
            # Not trading: re-check the case status every 100 ms so we start
            # within a tenth of a second of the instructor pressing start.
            time.sleep(0.1)
            last_case_poll = 0.0
            continue

        top = client.get_top()
        if top is None:
            time.sleep(0.01)
            continue

        # --- hot path: four subtractions, no allocation when flat ---------- #
        opp = detect_cross_raw(top[0], top[1], top[2], top[3],
                               top[5], top[6], top[7], top[8],
                               cost, min_profit)

        if opp is None:
            # Post-trade flatten check folded into the poll we just did.
            if monitor is not None and now >= monitor.next_check:
                # Once every --regime-interval seconds, off the hot path: read
                # counters the trading path already accumulated and republish
                # the three knobs below as locals.
                monitor.evaluate(now, top)
                min_profit = monitor.min_profit
                depth = monitor.depth
                max_rounds = monitor.max_rounds
            if quoter is not None and quoter.enabled:
                # While quoting, the quote thread owns ALL position repair: a
                # passive fill and its hedge must not race a flatten from here,
                # or the two of them churn the position across the spread.
                quoter.on_poll(top, now)
            elif not cfg.dry_run and guard.confirm(guard.net(top[4], top[9]), now):
                # Only a net that survived two polls 300 ms apart: positions lag
                # fills, and acting on a hedge in flight is how a flatten
                # becomes a spiral.
                flatten_from_top(client, cfg, tally, top, guard)
            interval = pacer.current(now)
            if interval > 0.0:
                time.sleep(interval)
            continue

        tally.crosses_seen += 1

        if cfg.dry_run:
            # Nothing we do changes the market, so the same cross reappears every
            # poll.  Report each distinct one at most once a second.
            key = (opp.direction, opp.ask_cheap, opp.bid_rich, opp.top_size)
            if key == last_dry_key and now - last_dry_time < 1.0:
                time.sleep(max(cfg.poll, 0.01))
                continue
            last_dry_key, last_dry_time = key, now
            LOG.info("CROSS [DRY RUN] %s buy %s @%.2f / sell %s @%.2f edge=%.4f "
                     "top_size=%d", opp.direction, opp.buy_ticker, opp.ask_cheap,
                     opp.sell_ticker, opp.bid_rich, opp.edge, opp.top_size)
            continue

        key = strike_key(opp, top)
        if not should_strike(key, last_key, last_strike_at, now,
                             restrike_cooldown):
            # Same prices AND same sizes as the cross we just took: this is the
            # client's stale view of a book we have already hit, not a second
            # opportunity.  Striking it again walks straight through the cross.
            tally.stale_restrikes += 1
            time.sleep(post_strike_sleep)
            continue
        last_key, last_strike_at = key, now
        strike(client, legs, books, opp, cfg, tally, tick, top[4], top[9],
               depth, max_rounds, min_profit, stats)
        # Give the client's quote view time to reflect our own fills before the
        # next poll; without this the loop re-polls in single-digit ms and sees
        # the cross it just took.
        if post_strike_sleep > 0.0:
            time.sleep(post_strike_sleep)
        if quoter is not None and quoter.enabled:
            # Never in front of the strike: a resting quote of ours may be in
            # the way of our own market order, but pulling it first would cost
            # a round trip on the one path where latency actually decides.
            quoter.cancel_all()
            quoter.reprime()


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="RIT ALGO1 cross-exchange arbitrage bot for CRZY_M / CRZY_A.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--api-key", default=os.environ.get("RIT_API_KEY", ""),
                   help="RIT API key (defaults to $RIT_API_KEY)")
    p.add_argument("--base-url", default=BASE_URL_DEFAULT,
                   help="RIT REST API base URL")
    p.add_argument("--min-profit", type=float, default=MIN_PROFIT_PER_SHARE,
                   help="required per-share edge, after costs, to trade")
    p.add_argument("--cost", type=float, default=TRADING_COST_PER_SHARE,
                   help="assumed trading cost per share, charged on EACH leg")
    p.add_argument("--poll", type=float, default=POLL_INTERVAL_SECONDS,
                   help="seconds between /securities polls (0 = as fast as possible)")
    p.add_argument("--rate-limit", type=float, default=0.0,
                   help="requests per second the RIT client allows, counted "
                        "across ALL endpoints (10 in the trial runs, 100 in the "
                        "final). 0 = no budget. Sets the poll rate for you.")
    p.add_argument("--rate-reserve", type=float, default=RATE_RESERVE_DEFAULT,
                   help="requests per second held back from polling so an order "
                        "insertion always has room (2 = one paired strike)")
    p.add_argument("--legs", choices=("scarce", "limit", "market"), default="scarce",
                   help="LIMIT legs priced at the crossed prices can never fill "
                        "worse than the price we saw (default); MARKET legs "
                        "always fill but pay whatever the book has moved to")
    p.add_argument("--limit-wait", type=float, default=LIMIT_WAIT_SECONDS,
                   help="seconds limit legs rest before everything is cancelled")
    p.add_argument("--imbalance-min", type=int, default=IMBALANCE_MIN,
                   help="shares of leg imbalance worth a market reversal")
    p.add_argument("--blind-size", type=int, default=BLIND_SIZE,
                   help="shares struck without a book read under --no-depth")
    p.add_argument("--restrike-cooldown", type=float, default=RESTRIKE_COOLDOWN,
                   help="seconds before an unchanged cross may be struck again; "
                        "the client's quote view lags our own fills")
    p.add_argument("--post-strike-sleep", type=float, default=POST_STRIKE_SLEEP,
                   help="seconds to wait after a strike before polling again, "
                        "so the next quote reflects the fills")
    p.add_argument("--position-mode", choices=("auto", "aggregated", "per-leg"),
                   default="auto",
                   help="how /securities reports positions. The real client "
                        "reports the AGGREGATED CRZY position on both tickers; "
                        "auto detects that from the two legs being equal.")
    p.add_argument("--margin", type=int, default=DEFAULT_SAFETY_MARGIN,
                   help="shares of headroom kept under the position limits")
    p.add_argument("--max-order", type=int, default=MAX_ORDER_SIZE,
                   help="max shares per order")
    p.add_argument("--position-limit", type=int, default=POSITION_LIMIT,
                   help="gross and net position limit in shares")
    p.add_argument("--max-rounds", type=int, default=5,
                   help="max paired orders fired at a single cross")
    p.add_argument("--dry-run", action="store_true",
                   help="detect and log crosses but submit no orders")
    depth = p.add_mutually_exclusive_group()
    depth.add_argument("--depth", dest="depth", action="store_true", default=None,
                       help="fetch both books in parallel with the first strike "
                            "and fire follow-up rounds against the depth "
                            "(default; pass it explicitly to keep depth even "
                            "under a small --rate-limit)")
    depth.add_argument("--no-depth", dest="depth", action="store_false",
                       help="never fetch the books; strike --blind-size only. "
                            "NOT recommended: bid_size/ask_size from "
                            "/securities are aggregate book sizes, not the top "
                            "level, so they cannot size an order.")
    p.add_argument("--quote", action="store_true",
                   help="opt-in passive quoting overlay (see README)")
    p.add_argument("--quote-size", type=int, default=QUOTE_SIZE_DEFAULT,
                   help="shares per resting quote")
    p.add_argument("--quote-tolerance", type=int, default=QUOTE_TOLERANCE_TICKS,
                   help="ticks a resting quote may drift before cancel/replace")
    p.add_argument("--requote-interval", type=float, default=REQUOTE_INTERVAL_SECONDS,
                   help="min seconds between cancel/replace on one ticker+side")
    p.add_argument("--max-divergence", type=int, default=MAX_DIVERGENCE_TICKS,
                   help="ticks of mid divergence that pause quoting")
    p.add_argument("--tick", type=float, default=None,
                   help="tick size override (default: inferred from the prices)")
    p.add_argument("--no-regime", dest="regime", action="store_false", default=True,
                   help="disable the regime monitor and run the plain fast bot")
    p.add_argument("--regime-interval", type=float, default=REGIME_INTERVAL_SECONDS,
                   help="seconds between regime evaluations")
    p.add_argument("--slip-threshold", type=float, default=None,
                   help="mean slippage per share that turns on CONSERVATIVE "
                        "(default: minus one tick)")
    p.add_argument("--regime-min-trades", type=int, default=REGIME_MIN_TRADES,
                   help="fills needed in a window before slippage is believed")
    p.add_argument("--unwind-threshold", type=float, default=UNWIND_THRESHOLD,
                   help="gross utilisation that switches to UNWIND")
    p.add_argument("--unwind-exit", type=float, default=UNWIND_EXIT,
                   help="gross utilisation that leaves UNWIND")
    p.add_argument("--flatten-at-ticks", dest="flatten_at", type=float,
                   default=FLATTEN_AT_TICKS,
                   help="ticks before the end of the case to cancel quotes and "
                        "flatten net exposure (a tick is NOT a second: the "
                        "trial ran about one tick every four seconds)")
    p.add_argument("--verbose", action="store_true", help="debug logging")
    return p.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s.%(msecs)03d %(levelname)-7s %(message)s",
        datefmt="%H:%M:%S",
        stream=sys.stdout,
    )

    if not args.api_key:
        LOG.error("No API key. Set RIT_API_KEY or pass --api-key "
                  "(find it via the API icon in the RIT client status bar).")
        return 2

    cfg = Config(
        api_key=args.api_key,
        base_url=args.base_url,
        min_profit=args.min_profit,
        cost=args.cost,
        poll=args.poll,
        rate_limit=args.rate_limit,
        rate_reserve=args.rate_reserve,
        restrike_cooldown=args.restrike_cooldown,
        post_strike_sleep=args.post_strike_sleep,
        position_mode=args.position_mode,
        legs=args.legs,
        limit_wait=args.limit_wait,
        imbalance_min=args.imbalance_min,
        blind_size=args.blind_size,
        margin=args.margin,
        max_order=args.max_order,
        position_limit=args.position_limit,
        dry_run=args.dry_run,
        depth=True if args.depth is None else args.depth,
        max_rounds=args.max_rounds,
        quote=args.quote,
        quote_size=args.quote_size,
        quote_tolerance=args.quote_tolerance,
        requote_interval=args.requote_interval,
        max_divergence=args.max_divergence,
        tick=args.tick,
        regime=args.regime,
        regime_interval=args.regime_interval,
        slip_threshold=args.slip_threshold,
        regime_min_trades=args.regime_min_trades,
        unwind_threshold=args.unwind_threshold,
        unwind_exit=args.unwind_exit,
        flatten_at=args.flatten_at,
    )
    if cfg.rate_limit and cfg.rate_limit <= SMALL_BUDGET and \
            args.rate_reserve == RATE_RESERVE_DEFAULT:
        # A cross now costs two book reads, two orders, a cancel and maybe a
        # reversal.  On a 10/s client that has to be reserved or the orders get
        # refused; what is left over is the polling rate.
        cfg.rate_reserve = RESERVE_SMALL_BUDGET
        LOG.info("Reserving %.0f requests/second for trading (a cross costs "
                 "2 book reads + 2 orders + a cancel).", cfg.rate_reserve)

    tally = Tally()
    budget = RequestBudget(cfg.rate_limit, cfg.rate_reserve)
    client = RitClient(cfg, tally, budget)
    if budget.enabled:
        LOG.info("Request budget: %.0f/s shared across all endpoints, %.0f/s "
                 "reserved for orders, polling every %.0f ms.",
                 budget.rate, budget.reserve, client.pacer.base * 1000.0)
    legs = ThreadPoolExecutor(max_workers=2, thread_name_prefix="leg")
    books = ThreadPoolExecutor(max_workers=2, thread_name_prefix="book")
    # The quote thread exists only if quoting could actually happen: explicitly
    # with --quote, or because UNWIND is reachable at this threshold.
    needs_quotes = cfg.quote or (cfg.regime and cfg.unwind_threshold <= 1.0)
    quote_pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="quote") \
        if needs_quotes else None
    quoter = Quoter(client, cfg, tally, quote_pool) if needs_quotes else None
    monitor = RegimeMonitor(cfg, tally, client, quoter) if cfg.regime else None

    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))

    LOG.info(
        "Starting ALGO1 arb | dry_run=%s depth=%s quote=%s regime=%s "
        "min_profit=%.4f cost=%.4f poll=%.3fs limit=%d margin=%d",
        cfg.dry_run, cfg.depth, cfg.quote, cfg.regime, cfg.min_profit, cfg.cost,
        cfg.poll, cfg.position_limit, cfg.margin,
    )
    try:
        main_loop(client, cfg, tally, legs, books, quoter, monitor)
    except KeyboardInterrupt:
        LOG.info("Interrupted - shutting down.")
    except Exception:
        LOG.exception("Unhandled error in the main loop")
    finally:
        if quote_pool is not None:
            # Stop the quote thread FIRST, otherwise it can post a fresh quote
            # after we have cancelled and leave an order resting on the book.
            quoter.stop()
            try:
                quote_pool.shutdown(wait=True, cancel_futures=True)
            except TypeError:                      # Python < 3.9
                quote_pool.shutdown(wait=True)
        if quoter is not None and not cfg.dry_run:
            try:
                quoter.cancel_all()
                client.cancel_all()
            except Exception:
                LOG.exception("Failed to cancel resting quotes on exit")
        legs.shutdown(wait=False)
        books.shutdown(wait=False)
        tally.poll_ms = client.pacer.interval * 1000.0
        LOG.info(tally.summary())
        client.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

import requests
import threading
import time

# --- Config ---
API_KEY = {'X-API-Key': 'T0KJGVY5'}
BASE_URL = 'http://localhost:10006/v1'

TICKER_M = 'CRZY_M'
TICKER_A = 'CRZY_A'

COST_PER_SHARE = 0.02   # per-share round-trip cost input
BUFFER = 0.01           # extra edge required above cost before firing
MAX_ORDER_SIZE = 10000
POSITION_LIMIT = 25000  # case aggregates M+A into one CRZY position
HEALTH_TIMEOUT = 2.0    # seconds since last good update before exchange is "unhealthy"
POLL_INTERVAL = 0.1
MAX_LOSS = 20000        # kill switch: stop trading and flatten if trading P&L drops below -this
MAX_REMAINDER_ATTEMPTS = 5   # give up forcing a full flatten after this many tries, not depth forever
REMAINDER_RETRY_DELAY = 0.1  # seconds between retries, gives a rejected order (e.g. rate limit) a moment to clear

session = requests.Session()
session.headers.update(API_KEY)

lock = threading.Lock()
state = {
    'net_position': 0,   # confirmed filled net position
    'reserved': 0,        # in-flight, not yet confirmed
    'last_update': {TICKER_M: time.time(), TICKER_A: time.time()},
}


def get_book(ticker):
    """
    Fetch top-of-book quote for one ticker.

    /securities/book returns individual resting orders, not aggregated price
    levels, and `limit` doesn't trim the response to one order. Each order's
    remaining size is quantity - quantity_filled (quantity is the ORIGINAL
    order size, confirmed against a live test server). So the best price's
    true depth is the sum of remaining size across every order sitting at it.

    Args: ticker (str) - e.g. 'CRZY_M'
    Returns: (bid_price, bid_depth, ask_price, ask_depth), or None on failure
             (or if either side of the book is empty)
    """
    resp = session.get(f'{BASE_URL}/securities/book', params={'ticker': ticker})
    if not resp.ok:
        return None
    book = resp.json()
    bids, asks = book.get('bids') or [], book.get('asks') or []
    if not bids or not asks:
        return None

    best_bid = max(o['price'] for o in bids)
    best_ask = min(o['price'] for o in asks)
    bid_depth = sum(o['quantity'] - o['quantity_filled'] for o in bids if o['price'] == best_bid)
    ask_depth = sum(o['quantity'] - o['quantity_filled'] for o in asks if o['price'] == best_ask)
    return best_bid, bid_depth, best_ask, ask_depth


def get_case():
    """
    Fetch current case state.
    Args: none
    Returns: dict with 'tick', 'status', 'ticks_per_period', 'total_periods',
             or None on failure. status is 'ACTIVE' / 'PAUSED' / 'STOPPED'.
    """
    resp = session.get(f'{BASE_URL}/case')
    return resp.json() if resp.ok else None


def submit_order(ticker, action, quantity, price=None):
    """
    Submit an order and return how much actually filled.

    price=None submits a MARKET order (fills at whatever price exists,
    no protection -- used only for remainder cleanup, where getting flat
    fast matters more than price). price=<value> submits a marketable
    LIMIT order capped at that price: it fills immediately against any
    available depth at or better than price, same as a market order would
    in a genuinely crossed book, but can never fill worse than price. If
    the book moved and it doesn't fully fill, the unfilled remainder rests
    in the book instead of chasing a worse price -- that remainder is
    cancelled immediately so it doesn't sit there and fill later at a
    stale, no-longer-profitable price.

    Confirmed live: blind MARKET orders on both legs caused real losses
    (buy price ended up above sell price) once the book moved between our
    quote check and order execution -- there's no such thing as "market
    orders that only fill if profitable" without a price cap.

    Args: ticker (str), action ('BUY'/'SELL'), quantity (int),
          price (float or None)
    Returns: filled quantity (int), 0 if the order failed
    """
    params = {'ticker': ticker, 'quantity': quantity, 'action': action}
    if price is not None:
        params['type'] = 'LIMIT'
        params['price'] = price
    else:
        params['type'] = 'MARKET'
    resp = session.post(f'{BASE_URL}/orders', params=params)
    if not resp.ok:
        return 0
    order = resp.json()
    filled = order.get('quantity_filled', 0)
    if price is not None and filled < quantity and order.get('order_id') is not None:
        session.delete(f'{BASE_URL}/orders/{order["order_id"]}')
    return filled


def cancel_all():
    """
    Cancel every open order on both exchanges (used as a kill switch).
    Args: none
    Returns: nothing
    """
    session.post(f'{BASE_URL}/commands/cancel', params={'all': 1})


def position_room():
    """
    How many more shares can be traded before hitting the position limit.
    Args: none
    Returns: remaining room (int), never negative
    """
    with lock:
        used = abs(state['net_position']) + abs(state['reserved'])
    return max(0, POSITION_LIMIT - used)


def mark_healthy(ticker):
    """
    Record that an exchange just gave a good response.
    Args: ticker (str)
    Returns: nothing
    """
    with lock:
        state['last_update'][ticker] = time.time()


def is_healthy(ticker):
    """
    Check whether an exchange has responded recently enough to trust.
    Args: ticker (str)
    Returns: True if within HEALTH_TIMEOUT, else False
    """
    with lock:
        return (time.time() - state['last_update'][ticker]) < HEALTH_TIMEOUT


def fire_leg(ticker, action, quantity, price, results, key):
    """
    Submit one leg of a trade; meant to run on its own thread so both
    legs of an arb go out at the same time instead of one after another.
    Args: ticker (str), action ('BUY'/'SELL'), quantity (int), price (float),
          results (dict to write into), key (str, which slot to fill)
    Returns: nothing (writes filled qty into results[key])
    """
    filled = submit_order(ticker, action, quantity, price)
    results[key] = filled
    mark_healthy(ticker)


def resolve_remainder(buy_ticker, sell_ticker, buy_filled, sell_filled):
    """
    Fix an uneven fill so we don't hold one-sided inventory.

    Single best-effort attempt (reverted from a retry-until-flat version):
    in a fast/high-order-rate environment, retrying crosses the spread
    repeatedly on every partial miss, which showed up live as real negative
    realized P&L rather than the intended variance reduction. One attempt
    trades a small chance of leftover residual position for not paying the
    spread over and over in a fast market.

    The corrective order changes the real position just like any other leg,
    so it must update state['net_position'] too -- skipping this was a real
    bug (confirmed live: local tracking silently drifted from RIT's actual
    position after every uneven fill, and flatten_all() trusted the stale
    local value at session end instead of the real one).

    Args: buy_ticker (str), sell_ticker (str),
          buy_filled (int), sell_filled (int) - actual filled quantities
    Returns: nothing
    """
    gap = buy_filled - sell_filled
    if gap > 0:
        filled = submit_order(sell_ticker, 'SELL', gap)
        with lock:
            state['net_position'] -= filled
    elif gap < 0:
        filled = submit_order(buy_ticker, 'BUY', -gap)
        with lock:
            state['net_position'] += filled


def execute_pair(buy_ticker, sell_ticker, qty, buy_price, sell_price):
    """
    Run one full arb trade: reserve size, fire both legs at once,
    reconcile the result, and patch up any uneven fill.

    buy_price/sell_price are the quoted ask/bid that made this look
    profitable -- passed through as limit caps so a stale/moved book
    produces a partial fill, never a trade at a losing price.

    Args: buy_ticker (str), sell_ticker (str), qty (int),
          buy_price (float), sell_price (float)
    Returns: nothing
    """
    with lock:
        state['reserved'] += qty  # reserve before sending, blocks double-firing this room

    results = {}
    t1 = threading.Thread(target=fire_leg, args=(buy_ticker, 'BUY', qty, buy_price, results, 'buy'))
    t2 = threading.Thread(target=fire_leg, args=(sell_ticker, 'SELL', qty, sell_price, results, 'sell'))
    t1.start(); t2.start()
    t1.join(); t2.join()

    buy_filled, sell_filled = results.get('buy', 0), results.get('sell', 0)
    with lock:
        state['reserved'] -= qty
        state['net_position'] += buy_filled - sell_filled

    if buy_filled != sell_filled:
        resolve_remainder(buy_ticker, sell_ticker, buy_filled, sell_filled)


def get_books_concurrent():
    """
    Fetch both tickers' books in parallel, not sequentially.

    try_arbitrage compares these two snapshots as if they were taken at the
    same instant. Fetching them one after another (as this originally did)
    leaves a real time gap between them -- confirmed live as a contributor
    to trading on a "cross" that was already stale or gone by execution
    time. Fetching concurrently shrinks that gap to ~one round-trip.

    Args: none
    Returns: (book_m, book_a), each as returned by get_book() (or None)
    """
    results = {}

    def fetch(ticker, key):
        results[key] = get_book(ticker)

    t1 = threading.Thread(target=fetch, args=(TICKER_M, 'm'))
    t2 = threading.Thread(target=fetch, args=(TICKER_A, 'a'))
    t1.start(); t2.start()
    t1.join(); t2.join()
    return results.get('m'), results.get('a')


def try_arbitrage():
    """
    One full check-and-trade cycle: verify both exchanges are healthy,
    pull current quotes, and fire a trade if a cross clears the cost
    threshold with room left under the position limit.
    Args: none
    Returns: nothing
    """
    if not (is_healthy(TICKER_M) and is_healthy(TICKER_A)):
        return  # one side stalled, don't trade blind

    book_m, book_a = get_books_concurrent()
    if book_m is None or book_a is None:
        return
    bid_m, size_bid_m, ask_m, size_ask_m = book_m
    bid_a, size_bid_a, ask_a, size_ask_a = book_a
    mark_healthy(TICKER_M)
    mark_healthy(TICKER_A)

    room = position_room()
    if room == 0:
        return
    threshold = COST_PER_SHARE + BUFFER

    if bid_a - ask_m > threshold:  # buy M, sell A
        qty = min(size_ask_m, size_bid_a, MAX_ORDER_SIZE, room)
        if qty > 0:
            execute_pair(TICKER_M, TICKER_A, qty, buy_price=ask_m, sell_price=bid_a)
        return  # only one direction per tick

    if bid_m - ask_a > threshold:  # buy A, sell M
        qty = min(size_ask_a, size_bid_m, MAX_ORDER_SIZE, room)
        if qty > 0:
            execute_pair(TICKER_A, TICKER_M, qty, buy_price=ask_a, sell_price=bid_m)


def get_security_state():
    """
    Fetch the full CRZY_M security record from RIT (position, realized,
    unrealized, etc. -- M and A report the same aggregate figures, confirmed
    live). This endpoint has been observed returning both a bare list and a
    dict wrapping the list under 'value' -- handle both rather than assume.
    Args: none
    Returns: dict, or None on failure
    """
    resp = session.get(f'{BASE_URL}/securities', params={'ticker': TICKER_M})
    if not resp.ok:
        return None
    body = resp.json()
    secs = body['value'] if isinstance(body, dict) and 'value' in body else body
    return secs[0] if isinstance(secs, list) else secs


def get_real_position():
    """
    Fetch the true aggregate CRZY position from RIT itself. Used as the
    authoritative source at flatten time instead of trusting local tracking,
    which can drift from reality if a fill is ever misaccounted locally.
    Args: none
    Returns: position (int), or None on failure
    """
    sec = get_security_state()
    return int(sec['position']) if sec is not None else None


def get_pnl():
    """
    Fetch current trading P&L (realized + unrealized) on the combined CRZY
    position, for the kill switch. Reads straight from RIT rather than any
    locally tracked figure, same reasoning as get_real_position().
    Args: none
    Returns: pnl (float), or None on failure
    """
    sec = get_security_state()
    return sec['realized'] + sec['unrealized'] if sec is not None else None


def flatten_all():
    """
    End-of-session cleanup: cancel resting orders and close any
    leftover position so nothing carries past the session.

    Reconciles against RIT's own reported position rather than trusting only
    local tracking -- local state can drift (see resolve_remainder), and this
    is the last chance to catch that before the session ends.

    Args: none
    Returns: nothing
    """
    cancel_all()
    pos = get_real_position()
    if pos is None:
        with lock:
            pos = state['net_position']  # fall back to local tracking if RIT is unreachable
    if pos > 0:
        submit_order(TICKER_M, 'SELL', pos)
    elif pos < 0:
        submit_order(TICKER_M, 'BUY', -pos)


def main():
    """
    Entry point: loop try_arbitrage() until the session ends, then flatten.

    Local position tracking starts at 0, but the real account might not be
    flat -- e.g. a previous run of this script was Ctrl+C'd mid-session, or
    this is being (re)started against a case that's already been trading.
    Confirmed live: starting local tracking at 0 against a real position of
    19,136 caused position_room() to think it had ~25,000 of room left when
    only ~5,864 actually remained, one bad trade away from a real limit
    breach. Syncing from RIT at startup fixes this regardless of cause.

    Also flattens in `finally` so a manual Ctrl+C still closes out any open
    position instead of abandoning it -- the interrupted run above is
    exactly how the account ended up out of sync in the first place.

    Args: none
    Returns: nothing
    """
    print('Starting ALGO1 arbitrage loop...')
    real_pos = get_real_position()
    with lock:
        state['net_position'] = real_pos if real_pos is not None else 0
    print(f'Synced starting position: {state["net_position"]}')

    try:
        while True:
            case = get_case()
            if case is None or case['status'] == 'STOPPED':
                break
            if case['status'] == 'ACTIVE':
                pnl = get_pnl()
                if pnl is not None and pnl < -MAX_LOSS:
                    print(f'KILL SWITCH: pnl={pnl:.2f} breached -{MAX_LOSS}, stopping and flattening')
                    break
                try_arbitrage()
            # PAUSED: skip trading this tick but keep polling for STOPPED
            time.sleep(POLL_INTERVAL)
    finally:
        flatten_all()
        print('Session ended, flattened.')


if __name__ == '__main__':
    main()

"""
arb.py -- pure cross-exchange arbitrage for RIT ALGO1 (CRZY_M / CRZY_A). Nothing else.

    python arb.py --key alex_roesler --port 45325

Console while running:  s = status   flat = flatten net now   q = flatten + quit

Facts about the class server this is built on (measured 9/10):
  * host must be "localhost"; reads are ~2ms and not rate-limited (1000+/s ok)
  * 10 orders/s per ticker, cancels count -> we stay at 8
  * position is AGGREGATE (+M/-A pairs are free); the only limit is |net| <= 25000,
    checked per order; /limits "net" is what RIT enforces but it LAGS fills by 100s of ms
  * order responses carry quantity_filled/vwap/status immediately
"""
import argparse, csv, os, sys, threading, time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
import requests

# ---------------- settings ----------------
POLL        = 0.010   # seconds between book scans
MIN_EDGE    = 0.01    # $/share (no fees in ALGO1: any cross qualifies)
MAX_ORDER   = 10000   # case rule
NET_LIMIT   = 24000   # 25000 with a buffer; each leg is checked on its own by RIT
MIN_QTY     = 100     # don't bother with crosses smaller than this
OPS         = 8       # orders+cancels per second per ticker we allow ourselves (server cap 10)
FAIL_COOL   = 0.5     # after a ONE-LEGGED result, don't retry that direction for this long (both-filled: retry at once)
MISS_COOL   = 0.15    # after a zero-fill result (cross already gone), brief pause instead of hammering
HEDGE_SLIP  = [(0.0, 0.02), (1.0, 0.05), (2.0, 0.10), (4.0, 0.20)]   # (seconds unhedged, max cents through top of book)
VOL_WINDOW  = 1.0     # seconds
VOL_MAX     = 0.20    # if either mid moved more than this within VOL_WINDOW, books are stale/phantom: open no NEW pairs
HEDGE_MIN   = 100     # ignore residual net smaller than this until the endgame
HEDGE_GAP   = 0.25    # seconds between hedge orders
SETTLE      = 5.0     # after a fill, trust local bookkeeping this long before the server's numbers
STABLE_N    = 20      # ...and only if /securities position AND /limits net AGREE and have been identical for this many polls (2s)
STORM_N     = 10      # >N hedge orders in 3s = bookkeeping diverged -> pause hedging 3s and resync from server
ENDGAME     = 6       # ticks before the end: stop opening, flatten to zero
TICKERS     = ("CRZY_M", "CRZY_A")
# ------------------------------------------


def pct(v, p):
    s = sorted(v)
    return s[min(len(s) - 1, int(len(s) * p))] if s else 0.0


class Arb:
    def __init__(self, host, port, key):
        self.base = f"http://{host}:{port}/v1"
        self.key = key
        self.local = threading.local()
        self.pool = ThreadPoolExecutor(max_workers=4)
        self.lock = threading.Lock()
        self.me = None
        self.net = 0                 # our best estimate of the aggregate position
        self.srv_net = None          # what /limits says (lags, swings during bursts, may count open orders)
        self.srv_pos = None          # what /securities says (the client's position record)
        self.srv_hist = deque(maxlen=STABLE_N)
        self.last_fill = 0.0
        self.sent = {t: deque(maxlen=50) for t in TICKERS}
        self.hedge_times = deque(maxlen=50)
        self.last_hedge = 0.0
        self.hedge_pause_until = 0.0
        self.unhedged_since = None
        self.cool = {}               # (buy_ticker, sell_ticker) -> time until which we skip it
        self.mids = {t: deque(maxlen=200) for t in TICKERS}   # (time, mid) for the volatility guard
        self.trading = True
        self.running = True
        self.case = {}
        self.nlv0 = None
        self.nlv = None
        self.lat = {}
        self.st = dict(arbs=0, sh=0, est=0.0, hedges=0, hsh=0, rej=0, flat_sh=0, hot=0)
        os.makedirs("logs", exist_ok=True)
        self.logf = open(f"logs/arb_{time.strftime('%Y%m%d_%H%M%S')}.csv", "w", newline="")
        self.logw = csv.writer(self.logf)
        self.logw.writerow(["wall", "tick", "tag", "ticker", "action", "type", "qty", "price",
                            "filled", "vwap", "status", "latency_ms", "net_local", "srv_pos", "srv_lim"])

    # ---------------- http ----------------
    def sess(self):
        s = getattr(self.local, "s", None)
        if s is None:
            s = requests.Session()
            s.trust_env = False
            s.headers.update({"X-API-key": self.key})
            self.local.s = s
        return s

    def req(self, method, path, params=None, key=None):
        t0 = time.perf_counter()
        try:
            r = self.sess().request(method, self.base + path, params=params, timeout=2)
        except requests.RequestException:
            return None, 0
        self.lat.setdefault(key or path, deque(maxlen=500)).append((time.perf_counter() - t0) * 1000)
        try:
            return r.json(), r.status_code
        except Exception:
            return None, r.status_code

    def get(self, path, params=None, key=None):
        js, code = self.req("GET", path, params, key)
        return js if code == 200 else None

    # ---------------- bookkeeping ----------------
    def apply_fill(self, action, qty):
        if qty > 0:
            with self.lock:
                self.net += qty if action == "BUY" else -qty
                self.last_fill = time.monotonic()

    def can_send(self, t):
        q = self.sent[t]
        now = time.monotonic()
        while q and now - q[0] > 1.0:
            q.popleft()
        return len(q) < OPS

    def log(self, tag, t, action, typ, qty, price, js, ms):
        self.logw.writerow([f"{time.time():.4f}", self.case.get("tick"), tag, t, action, typ, qty, price,
                            (js or {}).get("quantity_filled"), (js or {}).get("vwap"),
                            (js or {}).get("status", "ERR"), f"{ms:.1f}", self.net, self.srv_pos, self.srv_net])
        self.logf.flush()

    def order(self, t, action, qty, typ, price=None, tag=""):
        """Send one order, apply its fill, cancel any residual and pick up late fills. Returns filled qty."""
        qty = int(qty)
        if qty <= 0 or not self.can_send(t):
            return 0
        p = {"ticker": t, "type": typ, "quantity": qty, "action": action}
        if typ == "LIMIT":
            p["price"] = round(price, 2)
        self.sent[t].append(time.monotonic())
        t0 = time.perf_counter()
        js, code = self.req("POST", "/orders", p, key="POST order")
        ms = (time.perf_counter() - t0) * 1000
        self.log(tag, t, action, typ, qty, p.get("price"), js if code == 200 else None, ms)
        if code != 200 or not js:
            self.st["rej"] += 1
            if self.st["rej"] <= 3:
                print(f"\n*** order {code} on {t} {action} {qty}: {str(js)[:120]}")
            return 0
        filled = int(js.get("quantity_filled") or 0)
        self.apply_fill(action, filled)
        if js.get("status") == "OPEN":                      # residual: cancel, then read final fill
            oid = js["order_id"]
            self.sent[t].append(time.monotonic())
            self.req("DELETE", f"/orders/{oid}", key="DELETE order")
            o = self.get(f"/orders/{oid}", key="GET order")
            if o:
                final = int(o.get("quantity_filled") or 0)
                if final > filled:
                    self.apply_fill(action, final - filled)
                    filled = final
                self.log(tag + "_FINAL", t, action, typ, qty, p.get("price"), o, 0.0)
        return filled

    # ---------------- market data ----------------
    def book(self, t):
        js = self.get("/securities/book", {"ticker": t, "limit": 30}, key="GET book")
        if not js:
            return None
        bids, asks = [], []
        for side, dst in (("bids", bids), ("asks", asks)):
            for o in js.get(side) or []:
                if o.get("trader_id") == self.me:
                    continue
                rem = int(o.get("quantity", 0)) - int(o.get("quantity_filled") or 0)
                if rem > 0 and o.get("price") is not None:
                    dst.append((float(o["price"]), rem))
        bids.sort(key=lambda x: -x[0])
        asks.sort()
        return bids, asks

    @staticmethod
    def walk(asks, bids, qcap):
        """Pair ask levels with bid levels while bid-ask >= MIN_EDGE. -> qty, worst_buy_px, worst_sell_px, est_profit"""
        i = j = q = 0
        pb = ps = None
        prof = 0.0
        if not asks or not bids:
            return 0, None, None, 0.0
        ar, br = asks[0][1], bids[0][1]
        while i < len(asks) and j < len(bids) and q < qcap:
            e = bids[j][0] - asks[i][0]
            if e < MIN_EDGE - 1e-9:
                break
            take = min(ar, br, qcap - q)
            q += take
            prof += take * e
            pb, ps = asks[i][0], bids[j][0]
            ar -= take
            br -= take
            if ar <= 0:
                i += 1
                ar = asks[i][1] if i < len(asks) else 0
            if br <= 0:
                j += 1
                br = bids[j][1] if j < len(bids) else 0
        return q, pb, ps, prof

    # ---------------- strategy ----------------
    def volatile(self, books):
        now = time.monotonic()
        hot = False
        for t in TICKERS:
            b = books.get(t)
            if b and b[0] and b[1]:
                self.mids[t].append((now, (b[0][0][0] + b[1][0][0]) / 2))
            recent = [m for ts, m in self.mids[t] if now - ts <= VOL_WINDOW]
            if len(recent) >= 2 and max(recent) - min(recent) > VOL_MAX:
                hot = True
        if hot:
            self.st["hot"] += 1
        return hot

    def try_arb(self, books):
        net = self.net
        room = NET_LIMIT - abs(net)                        # room for NEW pairs; flattening never needs room
        best = None
        for X, Y in ((TICKERS[0], TICKERS[1]), (TICKERS[1], TICKERS[0])):   # buy X, sell Y
            bx, by = books.get(X), books.get(Y)
            if not bx or not by:
                continue
            q, pb, ps, prof = self.walk(bx[1], by[0], MAX_ORDER)
            if q >= MIN_QTY and (best is None or prof > best[0]):
                best = (prof, X, Y, q, pb, ps)
        if best is None:
            return
        prof, X, Y, q, pb, ps = best
        if time.monotonic() < self.cool.get((X, Y), 0):
            return
        # Inventory first: a cross that reduces our net is the cheapest possible flatten,
        # so take that single leg on its own instead of paying a hedge later.
        if net <= -HEDGE_MIN and self.can_send(X):
            f = self.order(X, "BUY", min(q, -net), "LIMIT", pb, "FLAT")
            self.st["flat_sh"] += f
            if f == 0:
                self.cool[(X, Y)] = time.monotonic() + MISS_COOL
            return
        if net >= HEDGE_MIN and self.can_send(Y):
            f = self.order(Y, "SELL", min(q, net), "LIMIT", ps, "FLAT")
            self.st["flat_sh"] += f
            if f == 0:
                self.cool[(X, Y)] = time.monotonic() + MISS_COOL
            return
        q = min(q, room)
        if q < MIN_QTY or self.volatile(books):
            return
        if not (self.can_send(X) and self.can_send(Y)):
            return
        f1 = self.pool.submit(self.order, X, "BUY", q, "LIMIT", pb, "ARB")
        f2 = self.pool.submit(self.order, Y, "SELL", q, "LIMIT", ps, "ARB")
        fb, fs = f1.result(), f2.result()
        self.st["arbs"] += 1
        self.st["sh"] += min(fb, fs)
        self.st["est"] += min(fb, fs) * (ps - pb)
        if (fb > 0) != (fs > 0) or (fb and fs and min(fb, fs) < 0.5 * max(fb, fs)):
            self.cool[(X, Y)] = time.monotonic() + FAIL_COOL      # one-legged / badly lopsided: that level was not real
        elif fb == 0 and fs == 0:
            self.cool[(X, Y)] = time.monotonic() + MISS_COOL

    def try_hedge(self, books, force=False):
        net = self.net
        thresh = 1 if force else HEDGE_MIN
        if abs(net) < thresh:
            self.unhedged_since = None
            return
        if self.unhedged_since is None:
            self.unhedged_since = time.monotonic()
        if time.monotonic() - self.last_hedge < HEDGE_GAP or time.monotonic() < self.hedge_pause_until:
            return
        side = "SELL" if net > 0 else "BUY"
        cands = []
        for t in TICKERS:
            b = books.get(t)
            if not b:
                continue
            lvl = b[0] if side == "SELL" else b[1]
            if lvl:
                cands.append((lvl[0][0] if side == "SELL" else -lvl[0][0], t))
        if not cands:
            return
        t = max(cands)[1]                                   # best bid to sell into / lowest ask to buy from
        self.last_hedge = time.monotonic()
        self.hedge_times.append(self.last_hedge)
        recent = sum(1 for x in self.hedge_times if self.last_hedge - x < 3.0)
        if recent > STORM_N and not force:
            print(f"\n*** {recent} hedges in 3s: pausing hedging 3s and resyncing net from server")
            self.hedge_pause_until = time.monotonic() + 3.0
            self.hedge_times.clear()
            with self.lock:
                self.last_fill = 0.0        # allow a server resync once it is stable
            return
        lvl = books[t][0] if side == "SELL" else books[t][1]
        top = lvl[0][0]
        if force:
            f = self.order(t, side, min(abs(net), MAX_ORDER), "MARKET", tag="HEDGE")
        else:
            waited = time.monotonic() - self.unhedged_since
            slip = max(c for secs, c in HEDGE_SLIP if waited >= secs)
            px = top - slip if side == "SELL" else top + slip
            f = self.order(t, side, min(abs(net), MAX_ORDER), "LIMIT", px, tag="HEDGE")
        self.st["hedges"] += 1
        self.st["hsh"] += f

    def flatten(self, rounds=5):
        for _ in range(rounds):
            if abs(self.net) < 1:
                break
            books = {t: self.book(t) for t in TICKERS}
            self.last_hedge = 0.0
            self.hedge_pause_until = 0.0
            self.try_hedge(books, force=True)
            time.sleep(0.3)

    # ---------------- loops ----------------
    def slow(self):
        """/case, /limits, /trader on a slow cadence."""
        k = 0
        while self.running:
            c = self.get("/case")
            if c:
                self.case = c
            lim = self.get("/limits", key="GET /limits")
            sec = self.get("/securities", key="GET /securities")
            try:
                if lim:
                    L = lim[0] if isinstance(lim, list) else lim
                    self.srv_net = int(round(float(L.get("net", 0))))
                if sec:
                    self.srv_pos = int(round(float(next(x["position"] for x in sec if x["ticker"] == TICKERS[0]))))
                if self.srv_net is not None and self.srv_pos is not None:
                    self.srv_hist.append((self.srv_net, self.srv_pos))
                    stable = (len(self.srv_hist) == STABLE_N and len(set(self.srv_hist)) == 1
                              and self.srv_net == self.srv_pos)
                    with self.lock:
                        if stable and time.monotonic() - self.last_fill > SETTLE and self.net != self.srv_pos:
                            print(f"\n*** resync: local net {self.net:+d} -> server {self.srv_pos:+d} "
                                  f"(/securities and /limits agree, stable 2s, idle 5s)")
                            self.net = self.srv_pos
            except Exception:
                pass
            if k % 10 == 0:
                tr = self.get("/trader")
                if tr and tr.get("nlv") is not None:
                    self.nlv = float(tr["nlv"])
                    if self.nlv0 is None and self.case.get("status") == "ACTIVE":
                        self.nlv0 = self.nlv
            k += 1
            time.sleep(0.1)

    def status(self):
        c = self.case
        pnl = (self.nlv - self.nlv0) if (self.nlv is not None and self.nlv0 is not None) else 0.0
        s = self.st
        line = (f"[t={c.get('tick')}/{c.get('ticks_per_period')} {c.get('status')}] PnL={pnl:+,.0f} | "
                f"net={self.net:+d} (srv pos {self.srv_pos} / lim {self.srv_net}) | arbs={s['arbs']} sh={s['sh']:,} est=${s['est']:,.0f} | "
                f"flat={s['flat_sh']:,} hedges={s['hedges']} hsh={s['hsh']:,} | rej={s['rej']} hot={s['hot']} | {'TRADING' if self.trading else 'STOPPED'}")
        lat = " | ".join(f"{k}: p50={pct(v,.5):.1f} p95={pct(v,.95):.1f}ms n={len(v)}" for k, v in sorted(self.lat.items()))
        return line + "\n   " + lat

    def console(self):
        for line in sys.stdin:
            cmd = line.strip().lower()
            if cmd in ("s", "status"):
                print(self.status())
            elif cmd == "flat":
                self.req("POST", "/commands/cancel", {"all": 1})
                self.flatten()
                print(self.status())
            elif cmd in ("q", "quit", "exit"):
                self.shutdown()
            elif cmd:
                print("commands: s | flat | q")

    def shutdown(self):
        print("Shutting down: cancel all, flatten net ...")
        self.req("POST", "/commands/cancel", {"all": 1})
        if self.case.get("status") == "ACTIVE":
            self.flatten()
        self.running = False
        self.logf.flush()
        print(self.status())
        print("CHECK the RIT Portfolio window: net should be 0.")
        os._exit(0)

    def run(self):
        print("Connecting ...")
        while self.running and not self.get("/case"):
            time.sleep(0.5)
        tr = self.get("/trader") or {}
        self.me = tr.get("trader_id")
        secs = self.get("/securities") or []
        for x in secs:
            if x["ticker"] in TICKERS:
                print(f"  {x['ticker']}: fee={x.get('trading_fee')} max/order={x.get('max_trade_size')} "
                      f"ops/s={x.get('api_orders_per_second')} delay={x.get('execution_delay_ms')}ms")
        threading.Thread(target=self.slow, daemon=True).start()
        threading.Thread(target=self.console, daemon=True).start()
        time.sleep(0.5)
        print(f"  server position now: /securities={self.srv_pos}  /limits net={self.srv_net}")
        if self.srv_pos:
            self.net = self.srv_pos
            print(f"  ** starting with net {self.net:+d}: will flatten it first")
        if self.srv_pos != self.srv_net:
            print("  ** WARNING: /securities and /limits DISAGREE. Resting orders or another process on this account? Check Task Manager for a second python.exe")
        print(f"Trader {self.me}  case={self.case.get('name')}  status={self.case.get('status')}  ready.  (s / flat / q)")
        was_active = False
        last_status = time.monotonic()
        while self.running:
            active = self.case.get("status") == "ACTIVE"
            if not active:
                if was_active:
                    print("\n*** case not active. Summary:\n" + self.status())
                    self.st = dict(arbs=0, sh=0, est=0.0, hedges=0, hsh=0, rej=0, flat_sh=0, hot=0)
                    self.nlv0 = None
                    self.trading = True
                was_active = False
                time.sleep(0.25)
                continue
            was_active = True
            books = {t: self.book(t) for t in TICKERS}
            self.volatile(books)
            rem = self.case.get("ticks_per_period", 300) - self.case.get("tick", 0)
            endgame = rem <= ENDGAME
            self.try_hedge(books, force=endgame)
            if self.trading and not endgame:
                self.try_arb(books)
            if time.monotonic() - last_status > 5:
                print(self.status())
                last_status = time.monotonic()
            time.sleep(POLL)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--key", required=True)
    ap.add_argument("--port", type=int, required=True)
    ap.add_argument("--host", default="localhost")
    a = ap.parse_args()
    bot = Arb(a.host, a.port, a.key)
    try:
        bot.run()
    except KeyboardInterrupt:
        bot.shutdown()
